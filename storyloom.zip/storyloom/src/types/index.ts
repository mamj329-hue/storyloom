// ============================================
// STORYLOOM — Core TypeScript Types
// ============================================

export type SubscriptionStatus = 'free' | 'basic' | 'premium'
export type NovelStatus = 'ongoing' | 'completed' | 'hiatus'
export type ContentType = 'short' | 'novel' | 'chapter'
export type PaymentStatus = 'pending' | 'success' | 'failed' | 'refunded'
export type SubscriptionPlan = 'basic' | 'premium'

export interface User {
  id: string
  clerk_id: string
  email: string
  username: string | null
  display_name: string | null
  avatar_url: string | null
  bio: string | null
  is_creator: boolean
  is_admin: boolean
  subscription_status: SubscriptionStatus
  subscription_expires_at: string | null
  paystack_customer_code: string | null
  total_earnings: number
  created_at: string
  updated_at: string
}

export interface Short {
  id: string
  creator_id: string
  title: string
  description: string | null
  video_url: string
  thumbnail_url: string | null
  cloudinary_public_id: string | null
  duration_seconds: number | null
  is_premium: boolean
  is_published: boolean
  view_count: number
  like_count: number
  comment_count: number
  tags: string[]
  genre: string | null
  created_at: string
  updated_at: string
  creator?: User
  is_liked?: boolean
  is_bookmarked?: boolean
}

export interface Novel {
  id: string
  creator_id: string
  title: string
  slug: string
  synopsis: string | null
  cover_url: string | null
  cloudinary_public_id: string | null
  genre: string
  tags: string[]
  status: NovelStatus
  is_published: boolean
  is_premium: boolean
  total_chapters: number
  view_count: number
  like_count: number
  rating: number
  rating_count: number
  created_at: string
  updated_at: string
  creator?: User
  is_liked?: boolean
  is_bookmarked?: boolean
}

export interface Chapter {
  id: string
  novel_id: string
  chapter_number: number
  title: string
  content: string
  word_count: number
  is_premium: boolean
  is_published: boolean
  view_count: number
  created_at: string
  updated_at: string
  novel?: Novel
}

export interface Comment {
  id: string
  user_id: string
  content_type: ContentType
  content_id: string
  parent_id: string | null
  body: string
  like_count: number
  is_pinned: boolean
  created_at: string
  updated_at: string
  user?: User
  replies?: Comment[]
}

export interface Subscription {
  id: string
  user_id: string
  plan: SubscriptionPlan
  status: 'active' | 'cancelled' | 'expired' | 'pending'
  paystack_subscription_code: string | null
  amount: number
  currency: string
  current_period_start: string | null
  current_period_end: string | null
  cancelled_at: string | null
  created_at: string
}

export interface Payment {
  id: string
  user_id: string
  subscription_id: string | null
  paystack_reference: string
  amount: number
  currency: string
  status: PaymentStatus
  metadata: Record<string, unknown>
  created_at: string
}

export interface PricingPlan {
  id: SubscriptionPlan
  name: string
  price: number
  currency: string
  interval: string
  features: string[]
  paystack_plan_code: string
  highlighted?: boolean
}

export const PRICING_PLANS: PricingPlan[] = [
  {
    id: 'basic',
    name: 'Reader',
    price: 1500,
    currency: 'NGN',
    interval: 'month',
    paystack_plan_code: process.env.NEXT_PUBLIC_PAYSTACK_BASIC_PLAN_CODE || '',
    features: [
      'Access all free shorts',
      'Read 10 premium chapters/month',
      'HD video quality',
      'Comment & like',
      'Bookmark content',
    ],
  },
  {
    id: 'premium',
    name: 'Unlimited',
    price: 3500,
    currency: 'NGN',
    interval: 'month',
    paystack_plan_code: process.env.NEXT_PUBLIC_PAYSTACK_PREMIUM_PLAN_CODE || '',
    highlighted: true,
    features: [
      'Everything in Reader',
      'Unlimited premium chapters',
      'All premium shorts',
      'Offline reading',
      'Early access to new releases',
      'Creator supporter badge',
    ],
  },
]

export const GENRES = [
  'Romance', 'Thriller', 'Fantasy', 'Sci-Fi', 'Horror',
  'Mystery', 'Drama', 'Comedy', 'Action', 'Historical',
  'Paranormal', 'Billionaire', 'Werewolf', 'Vampire', 'YA',
] as const

export type Genre = typeof GENRES[number]
