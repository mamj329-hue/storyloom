// src/components/shared/PricingCards.tsx
'use client'
import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { Check, Loader2, Sparkles } from 'lucide-react'
import type { PricingPlan } from '@/types'
import { formatCurrency } from '@/lib/utils'
import { cn } from '@/lib/utils'
import toast from 'react-hot-toast'

interface Props {
  plans: PricingPlan[]
  currentPlan: string
  userEmail?: string
}

export default function PricingCards({ plans, currentPlan, userEmail }: Props) {
  const [loading, setLoading] = useState<string | null>(null)
  const router = useRouter()

  const handleSubscribe = async (plan: PricingPlan) => {
    if (!userEmail) { router.push('/auth/sign-up'); return }
    if (currentPlan === plan.id) { toast('You are already on this plan'); return }

    setLoading(plan.id)
    try {
      const res = await fetch('/api/subscriptions/initialize', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ plan: plan.id }),
      })
      const data = await res.json()
      if (data.authorization_url) {
        window.location.href = data.authorization_url
      } else {
        toast.error(data.error || 'Something went wrong')
      }
    } catch {
      toast.error('Failed to initiate checkout')
    } finally {
      setLoading(null)
    }
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-2xl mx-auto">
      {plans.map((plan) => (
        <div
          key={plan.id}
          className={cn(
            'relative rounded-3xl p-8 border transition-all duration-300',
            plan.highlighted
              ? 'bg-gradient-to-br from-parchment-900/60 to-ink-950 border-parchment-600/50 shadow-xl shadow-parchment-900/20'
              : 'bg-ink-950/60 border-ink-800/50'
          )}
        >
          {plan.highlighted && (
            <div className="absolute -top-3.5 left-1/2 -translate-x-1/2">
              <span className="bg-parchment-500 text-obsidian text-xs font-bold px-4 py-1.5 rounded-full flex items-center gap-1.5">
                <Sparkles size={12} /> Most Popular
              </span>
            </div>
          )}

          <div className="mb-6">
            <h3 className="font-display text-xl font-bold text-cream mb-1">{plan.name}</h3>
            <div className="flex items-baseline gap-1">
              <span className="text-3xl font-bold text-cream">
                {formatCurrency(plan.price, plan.currency)}
              </span>
              <span className="text-cream/40 text-sm">/{plan.interval}</span>
            </div>
          </div>

          <ul className="space-y-3 mb-8">
            {plan.features.map((feature) => (
              <li key={feature} className="flex items-start gap-2.5 text-sm">
                <Check size={15} className="text-parchment-400 mt-0.5 flex-shrink-0" />
                <span className="text-cream/70">{feature}</span>
              </li>
            ))}
          </ul>

          <button
            onClick={() => handleSubscribe(plan)}
            disabled={!!loading || currentPlan === plan.id}
            className={cn(
              'w-full py-3 rounded-full font-semibold text-sm transition-all duration-200 flex items-center justify-center gap-2',
              currentPlan === plan.id
                ? 'bg-ink-800 text-cream/40 cursor-default'
                : plan.highlighted
                  ? 'bg-parchment-500 hover:bg-parchment-400 text-obsidian active:scale-95'
                  : 'border border-ink-600 hover:border-parchment-600 text-cream hover:text-parchment-300 active:scale-95'
            )}
          >
            {loading === plan.id && <Loader2 size={15} className="animate-spin" />}
            {currentPlan === plan.id ? 'Current Plan' : `Subscribe — ${formatCurrency(plan.price, plan.currency)}/mo`}
          </button>
        </div>
      ))}
    </div>
  )
}
