// src/components/shared/Navbar.tsx
'use client'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { SignInButton, SignUpButton, UserButton, useUser } from '@clerk/nextjs'
import { Play, BookOpen, Crown, LayoutDashboard, Menu, X } from 'lucide-react'
import { useState } from 'react'
import { cn } from '@/lib/utils'

const NAV_LINKS = [
  { href: '/shorts', label: 'Shorts', icon: Play },
  { href: '/novels', label: 'Novels', icon: BookOpen },
  { href: '/pricing', label: 'Premium', icon: Crown },
]

export default function Navbar() {
  const pathname = usePathname()
  const { isSignedIn } = useUser()
  const [mobileOpen, setMobileOpen] = useState(false)

  return (
    <header className="fixed top-0 left-0 right-0 z-50 glass border-b border-ink-800/40">
      <nav className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
        {/* Logo */}
        <Link href="/" className="flex items-center gap-2 group">
          <span className="font-display text-2xl font-bold gradient-text tracking-tight">
            StoryLoom
          </span>
        </Link>

        {/* Desktop Nav */}
        <div className="hidden md:flex items-center gap-1">
          {NAV_LINKS.map(({ href, label, icon: Icon }) => (
            <Link
              key={href}
              href={href}
              className={cn(
                'flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium transition-all duration-200',
                pathname.startsWith(href)
                  ? 'bg-parchment-500/20 text-parchment-300'
                  : 'text-cream/60 hover:text-cream hover:bg-ink-800/60'
              )}
            >
              <Icon size={15} />
              {label}
            </Link>
          ))}
        </div>

        {/* Auth */}
        <div className="hidden md:flex items-center gap-3">
          {isSignedIn ? (
            <>
              <Link
                href="/dashboard/creator"
                className="flex items-center gap-2 text-sm text-cream/60 hover:text-cream transition-colors"
              >
                <LayoutDashboard size={15} />
                Dashboard
              </Link>
              <UserButton afterSignOutUrl="/" />
            </>
          ) : (
            <>
              <SignInButton mode="modal">
                <button className="text-sm text-cream/70 hover:text-cream transition-colors px-4 py-2">
                  Sign in
                </button>
              </SignInButton>
              <SignUpButton mode="modal">
                <button className="btn-primary text-sm py-2 px-5">
                  Get started
                </button>
              </SignUpButton>
            </>
          )}
        </div>

        {/* Mobile toggle */}
        <button
          className="md:hidden text-cream/70 hover:text-cream"
          onClick={() => setMobileOpen(!mobileOpen)}
        >
          {mobileOpen ? <X size={22} /> : <Menu size={22} />}
        </button>
      </nav>

      {/* Mobile menu */}
      {mobileOpen && (
        <div className="md:hidden bg-ink-950/95 backdrop-blur-xl border-t border-ink-800/40 px-4 py-4 flex flex-col gap-2">
          {NAV_LINKS.map(({ href, label, icon: Icon }) => (
            <Link
              key={href}
              href={href}
              onClick={() => setMobileOpen(false)}
              className={cn(
                'flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium',
                pathname.startsWith(href)
                  ? 'bg-parchment-500/20 text-parchment-300'
                  : 'text-cream/70 hover:bg-ink-800'
              )}
            >
              <Icon size={16} /> {label}
            </Link>
          ))}
          <div className="border-t border-ink-800 pt-3 mt-1 flex flex-col gap-2">
            {isSignedIn ? (
              <div className="flex items-center gap-3 px-4">
                <UserButton afterSignOutUrl="/" />
                <span className="text-sm text-cream/60">Account</span>
              </div>
            ) : (
              <>
                <SignInButton mode="modal">
                  <button className="btn-ghost text-sm w-full" onClick={() => setMobileOpen(false)}>Sign in</button>
                </SignInButton>
                <SignUpButton mode="modal">
                  <button className="btn-primary text-sm w-full" onClick={() => setMobileOpen(false)}>Get started</button>
                </SignUpButton>
              </>
            )}
          </div>
        </div>
      )}
    </header>
  )
}
