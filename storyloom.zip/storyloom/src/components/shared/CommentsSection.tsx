// src/components/shared/CommentsSection.tsx
'use client'
import { useState, useEffect } from 'react'
import Image from 'next/image'
import { useUser, SignInButton } from '@clerk/nextjs'
import { MessageCircle, Trash2, Send, Loader2 } from 'lucide-react'
import type { Comment, ContentType } from '@/types'
import { formatDate } from '@/lib/utils'
import toast from 'react-hot-toast'

interface Props {
  contentType: ContentType
  contentId: string
}

export default function CommentsSection({ contentType, contentId }: Props) {
  const { isSignedIn, user } = useUser()
  const [comments, setComments] = useState<Comment[]>([])
  const [loading, setLoading] = useState(true)
  const [body, setBody] = useState('')
  const [submitting, setSubmitting] = useState(false)

  useEffect(() => {
    fetch(`/api/comments?content_type=${contentType}&content_id=${contentId}`)
      .then(r => r.json())
      .then(d => setComments(d.comments || []))
      .finally(() => setLoading(false))
  }, [contentType, contentId])

  const handleSubmit = async () => {
    if (!body.trim()) return
    setSubmitting(true)
    try {
      const res = await fetch('/api/comments', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ content_type: contentType, content_id: contentId, body }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error)
      setComments(prev => [data.comment, ...prev])
      setBody('')
    } catch (err: any) {
      toast.error(err.message || 'Failed to post comment')
    } finally {
      setSubmitting(false)
    }
  }

  const handleDelete = async (commentId: string) => {
    await fetch('/api/comments', {
      method: 'DELETE',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ comment_id: commentId }),
    })
    setComments(prev => prev.filter(c => c.id !== commentId))
    toast.success('Comment deleted')
  }

  return (
    <section className="mt-12 pt-8 border-t border-ink-800/40">
      <h3 className="font-display text-xl font-semibold text-cream mb-6 flex items-center gap-2">
        <MessageCircle size={20} className="text-parchment-500" />
        Comments <span className="text-cream/30 font-normal text-base ml-1">({comments.length})</span>
      </h3>

      {/* Composer */}
      {isSignedIn ? (
        <div className="flex gap-3 mb-8">
          {user.imageUrl && (
            <Image src={user.imageUrl} alt="" width={36} height={36} className="rounded-full flex-shrink-0 mt-1" />
          )}
          <div className="flex-1">
            <textarea
              value={body}
              onChange={e => setBody(e.target.value)}
              onKeyDown={e => { if (e.key === 'Enter' && e.metaKey) handleSubmit() }}
              placeholder="Share your thoughts..."
              rows={3}
              className="w-full bg-ink-900 border border-ink-700 focus:border-parchment-600 rounded-xl px-4 py-3 text-cream text-sm outline-none transition-colors resize-none"
            />
            <div className="flex justify-end mt-2">
              <button
                onClick={handleSubmit}
                disabled={submitting || !body.trim()}
                className="btn-primary text-sm py-2 px-5 flex items-center gap-2 disabled:opacity-50"
              >
                {submitting ? <Loader2 size={14} className="animate-spin" /> : <Send size={14} />}
                Post
              </button>
            </div>
          </div>
        </div>
      ) : (
        <div className="glass rounded-xl p-4 mb-8 text-center">
          <p className="text-cream/50 text-sm mb-3">Sign in to join the conversation</p>
          <SignInButton mode="modal">
            <button className="btn-primary text-sm py-2 px-6">Sign in</button>
          </SignInButton>
        </div>
      )}

      {/* Comment list */}
      {loading ? (
        <div className="flex justify-center py-8">
          <Loader2 size={24} className="animate-spin text-parchment-500/50" />
        </div>
      ) : comments.length === 0 ? (
        <p className="text-cream/30 text-sm text-center py-8">No comments yet. Be the first!</p>
      ) : (
        <div className="space-y-5">
          {comments.map(comment => (
            <div key={comment.id} className="flex gap-3">
              {comment.user?.avatar_url ? (
                <Image src={comment.user.avatar_url} alt="" width={32} height={32} className="rounded-full flex-shrink-0 mt-1" />
              ) : (
                <div className="w-8 h-8 rounded-full bg-ink-800 flex-shrink-0 mt-1" />
              )}
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-cream text-sm font-semibold">
                    {comment.user?.display_name || comment.user?.username || 'Anonymous'}
                  </span>
                  {comment.is_pinned && (
                    <span className="text-xs bg-parchment-900/40 text-parchment-400 px-2 py-0.5 rounded-full">Pinned</span>
                  )}
                  <span className="text-cream/30 text-xs">{formatDate(comment.created_at)}</span>
                </div>
                <p className="text-cream/80 text-sm leading-relaxed">{comment.body}</p>
              </div>
              {isSignedIn && user?.id === comment.user?.clerk_id && (
                <button
                  onClick={() => handleDelete(comment.id)}
                  className="text-cream/20 hover:text-red-400 transition-colors mt-1 flex-shrink-0"
                >
                  <Trash2 size={13} />
                </button>
              )}
            </div>
          ))}
        </div>
      )}
    </section>
  )
}
