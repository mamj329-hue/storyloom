// src/components/shorts/ShortsNav.tsx
'use client'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { Play, BookOpen, Crown, User, Search } from 'lucide-react'
import { useUser, SignInButton } from '@clerk/nextjs'
import { cn } from '@/lib/utils'

const TABS = [
  { href: '/shorts', label: 'Shorts', icon: Play },
  { href: '/novels', label: 'Novels', icon: BookOpen },
  { href: '/pricing', label: 'Premium', icon: Crown },
]

export default function ShortsNav() {
  const pathname = usePathname()
  const { isSignedIn } = useUser()

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 flex items-center justify-around px-2 py-2 pb-safe bg-obsidian/90 backdrop-blur-xl border-t border-ink-800/50 md:hidden">
      {TABS.map(({ href, label, icon: Icon }) => (
        <Link
          key={href}
          href={href}
          className={cn(
            'flex flex-col items-center gap-0.5 px-4 py-1.5 rounded-xl transition-all',
            pathname.startsWith(href)
              ? 'text-parchment-300'
              : 'text-cream/40'
          )}
        >
          <Icon size={22} className={pathname.startsWith(href) ? 'fill-parchment-300/20' : ''} />
          <span className="text-[10px] font-medium">{label}</span>
        </Link>
      ))}

      {isSignedIn ? (
        <Link
          href="/dashboard/creator"
          className={cn(
            'flex flex-col items-center gap-0.5 px-4 py-1.5 rounded-xl transition-all',
            pathname.startsWith('/dashboard') ? 'text-parchment-300' : 'text-cream/40'
          )}
        >
          <User size={22} />
          <span className="text-[10px] font-medium">Me</span>
        </Link>
      ) : (
        <SignInButton mode="modal">
          <button className="flex flex-col items-center gap-0.5 px-4 py-1.5 text-cream/40">
            <User size={22} />
            <span className="text-[10px] font-medium">Sign in</span>
          </button>
        </SignInButton>
      )}
    </nav>
  )
}
