// src/components/shorts/ShortItem.tsx
'use client'
import { useRef, useState, useEffect } from 'react'
import { useInView } from 'react-intersection-observer'
import Image from 'next/image'
import Link from 'next/link'
import { Heart, MessageCircle, Bookmark, Share2, Volume2, VolumeX, Lock, Play, Pause } from 'lucide-react'
import { useUser } from '@clerk/nextjs'
import type { Short } from '@/types'
import { formatCount } from '@/lib/utils'
import { cn } from '@/lib/utils'
import toast from 'react-hot-toast'

interface Props {
  short: Short
  isActive: boolean
  onVisible: () => void
  index: number
}

export default function ShortItem({ short, isActive, onVisible, index }: Props) {
  const videoRef = useRef<HTMLVideoElement>(null)
  const [muted, setMuted] = useState(true)
  const [paused, setPaused] = useState(false)
  const [liked, setLiked] = useState(short.is_liked || false)
  const [likeCount, setLikeCount] = useState(short.like_count)
  const [bookmarked, setBookmarked] = useState(short.is_bookmarked || false)
  const { isSignedIn } = useUser()

  const { ref } = useInView({
    threshold: 0.7,
    onChange: (inView) => { if (inView) onVisible() },
  })

  useEffect(() => {
    const video = videoRef.current
    if (!video) return
    if (isActive) {
      video.play().catch(() => {})
      setPaused(false)
    } else {
      video.pause()
      video.currentTime = 0
    }
  }, [isActive])

  const togglePlay = () => {
    const video = videoRef.current
    if (!video) return
    if (video.paused) { video.play(); setPaused(false) }
    else { video.pause(); setPaused(true) }
  }

  const toggleMute = () => {
    if (videoRef.current) {
      videoRef.current.muted = !muted
      setMuted(!muted)
    }
  }

  const handleLike = async () => {
    if (!isSignedIn) { toast.error('Sign in to like'); return }
    const newLiked = !liked
    setLiked(newLiked)
    setLikeCount(c => newLiked ? c + 1 : c - 1)
    await fetch('/api/likes', {
      method: newLiked ? 'POST' : 'DELETE',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ content_type: 'short', content_id: short.id }),
    })
  }

  const handleBookmark = async () => {
    if (!isSignedIn) { toast.error('Sign in to bookmark'); return }
    setBookmarked(!bookmarked)
    await fetch('/api/bookmarks', {
      method: bookmarked ? 'DELETE' : 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ content_type: 'short', content_id: short.id }),
    })
  }

  const handleShare = async () => {
    const url = `${window.location.origin}/shorts/${short.id}`
    if (navigator.share) {
      await navigator.share({ title: short.title, url })
    } else {
      await navigator.clipboard.writeText(url)
      toast.success('Link copied!')
    }
  }

  return (
    <div ref={ref} className="shorts-video-item relative bg-obsidian flex items-center justify-center">
      {/* Video */}
      <div className="relative w-full h-full max-w-sm mx-auto" onClick={togglePlay}>
        {short.is_premium && !isSignedIn ? (
          <div className="w-full h-full bg-ink-950 flex flex-col items-center justify-center gap-4">
            {short.thumbnail_url && (
              <Image src={short.thumbnail_url} alt={short.title} fill className="object-cover opacity-30 blur-sm" />
            )}
            <div className="relative z-10 flex flex-col items-center gap-3 text-center px-6">
              <Lock size={40} className="text-parchment-400" />
              <p className="font-display text-xl text-cream">Premium Content</p>
              <p className="text-cream/60 text-sm">Subscribe to watch this short</p>
              <Link href="/pricing" className="btn-primary mt-2">Unlock Premium</Link>
            </div>
          </div>
        ) : (
          <>
            <video
              ref={videoRef}
              src={short.video_url}
              poster={short.thumbnail_url || undefined}
              loop
              muted={muted}
              playsInline
              className="w-full h-full object-cover"
            />
            {paused && (
              <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                <div className="bg-black/40 rounded-full p-4">
                  <Play size={40} className="text-white fill-white" />
                </div>
              </div>
            )}
          </>
        )}

        {/* Gradient overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-obsidian/90 via-transparent to-transparent pointer-events-none" />

        {/* Bottom info */}
        <div className="absolute bottom-0 left-0 right-14 p-4 pointer-events-none">
          <Link
            href={`/creator/${short.creator?.username}`}
            className="flex items-center gap-2 mb-2 pointer-events-auto"
          >
            {short.creator?.avatar_url && (
              <Image
                src={short.creator.avatar_url}
                alt={short.creator.display_name || ''}
                width={32} height={32}
                className="rounded-full border border-parchment-500/40"
              />
            )}
            <span className="text-cream text-sm font-semibold">
              @{short.creator?.username || short.creator?.display_name}
            </span>
          </Link>
          <h3 className="text-cream font-semibold text-base mb-1 line-clamp-2">{short.title}</h3>
          {short.description && (
            <p className="text-cream/70 text-sm line-clamp-2">{short.description}</p>
          )}
          {short.genre && (
            <span className="inline-block mt-1 text-xs bg-parchment-500/20 text-parchment-300 px-2 py-0.5 rounded-full">
              #{short.genre}
            </span>
          )}
        </div>
      </div>

      {/* Right sidebar actions */}
      <div className="absolute right-3 bottom-20 flex flex-col items-center gap-5">
        <button onClick={handleLike} className="flex flex-col items-center gap-1">
          <Heart
            size={28}
            className={cn('transition-all', liked ? 'fill-crimson-500 text-crimson-500 scale-110' : 'text-cream')}
          />
          <span className="text-cream text-xs font-medium">{formatCount(likeCount)}</span>
        </button>

        <button className="flex flex-col items-center gap-1">
          <MessageCircle size={28} className="text-cream" />
          <span className="text-cream text-xs font-medium">{formatCount(short.comment_count)}</span>
        </button>

        <button onClick={handleBookmark} className="flex flex-col items-center gap-1">
          <Bookmark
            size={28}
            className={cn('transition-all', bookmarked ? 'fill-parchment-400 text-parchment-400' : 'text-cream')}
          />
        </button>

        <button onClick={handleShare} className="flex flex-col items-center gap-1">
          <Share2 size={28} className="text-cream" />
        </button>

        <button onClick={toggleMute}>
          {muted
            ? <VolumeX size={24} className="text-cream/70" />
            : <Volume2 size={24} className="text-cream" />
          }
        </button>
      </div>
    </div>
  )
}
