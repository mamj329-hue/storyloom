// src/components/shorts/ShortsFeed.tsx
'use client'
import { useRef, useState, useCallback } from 'react'
import { useInView } from 'react-intersection-observer'
import type { Short } from '@/types'
import ShortItem from './ShortItem'

interface Props { initialShorts: Short[] }

export default function ShortsFeed({ initialShorts }: Props) {
  const [shorts, setShorts] = useState(initialShorts)
  const [activeIndex, setActiveIndex] = useState(0)
  const [loading, setLoading] = useState(false)
  const containerRef = useRef<HTMLDivElement>(null)

  const { ref: bottomRef } = useInView({
    threshold: 0.1,
    onChange: async (inView) => {
      if (!inView || loading) return
      setLoading(true)
      try {
        const res = await fetch(`/api/shorts?offset=${shorts.length}&limit=10`)
        const data = await res.json()
        if (data.shorts?.length) setShorts(prev => [...prev, ...data.shorts])
      } finally {
        setLoading(false)
      }
    },
  })

  return (
    <div
      ref={containerRef}
      className="shorts-video-container scrollbar-hide"
      style={{ height: '100dvh' }}
    >
      {shorts.map((short, i) => (
        <ShortItem
          key={short.id}
          short={short}
          isActive={activeIndex === i}
          onVisible={() => setActiveIndex(i)}
          index={i}
        />
      ))}

      {/* Infinite scroll trigger */}
      <div ref={bottomRef} className="h-4" />

      {loading && (
        <div className="flex justify-center py-8">
          <div className="w-6 h-6 border-2 border-parchment-500 border-t-transparent rounded-full animate-spin" />
        </div>
      )}
    </div>
  )
}
