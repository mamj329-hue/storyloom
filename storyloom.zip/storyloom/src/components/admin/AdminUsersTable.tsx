// src/components/admin/AdminUsersTable.tsx
'use client'
import { useState } from 'react'
import { ShieldCheck, Pen, Crown, Ban, Search } from 'lucide-react'
import { formatDate, formatCurrency } from '@/lib/utils'
import { cn } from '@/lib/utils'
import toast from 'react-hot-toast'
import type { User } from '@/types'

interface Props { users: User[] }

export default function AdminUsersTable({ users: initialUsers }: Props) {
  const [users, setUsers] = useState(initialUsers)
  const [search, setSearch] = useState('')

  const filtered = users.filter(u =>
    (u.display_name || '').toLowerCase().includes(search.toLowerCase()) ||
    u.email.toLowerCase().includes(search.toLowerCase()) ||
    (u.username || '').toLowerCase().includes(search.toLowerCase())
  )

  const toggleCreator = async (userId: string, current: boolean) => {
    await fetch(`/api/admin/users/${userId}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ is_creator: !current }),
    })
    setUsers(prev => prev.map(u => u.id === userId ? { ...u, is_creator: !current } : u))
    toast.success(!current ? 'Creator access granted' : 'Creator access revoked')
  }

  const toggleAdmin = async (userId: string, current: boolean) => {
    if (!confirm(`${current ? 'Revoke' : 'Grant'} admin access?`)) return
    await fetch(`/api/admin/users/${userId}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ is_admin: !current }),
    })
    setUsers(prev => prev.map(u => u.id === userId ? { ...u, is_admin: !current } : u))
    toast.success(!current ? 'Admin access granted' : 'Admin access revoked')
  }

  return (
    <div>
      {/* Search */}
      <div className="relative mb-6 max-w-sm">
        <Search size={15} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-cream/30" />
        <input
          value={search}
          onChange={e => setSearch(e.target.value)}
          placeholder="Search users..."
          className="w-full bg-ink-900 border border-ink-700 focus:border-parchment-600 rounded-xl pl-10 pr-4 py-2.5 text-cream text-sm outline-none transition-colors"
        />
      </div>

      <div className="glass rounded-2xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-ink-800/60">
                <th className="text-left text-cream/40 font-medium px-5 py-3.5">User</th>
                <th className="text-left text-cream/40 font-medium px-4 py-3.5 hidden md:table-cell">Plan</th>
                <th className="text-left text-cream/40 font-medium px-4 py-3.5 hidden lg:table-cell">Earnings</th>
                <th className="text-left text-cream/40 font-medium px-4 py-3.5 hidden lg:table-cell">Joined</th>
                <th className="text-left text-cream/40 font-medium px-4 py-3.5">Roles</th>
                <th className="text-right text-cream/40 font-medium px-5 py-3.5">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((user, i) => (
                <tr
                  key={user.id}
                  className={cn('border-b border-ink-800/30 hover:bg-ink-900/40 transition-colors', i === filtered.length - 1 && 'border-0')}
                >
                  <td className="px-5 py-3.5">
                    <p className="text-cream font-medium text-sm">{user.display_name || user.username || '—'}</p>
                    <p className="text-cream/40 text-xs mt-0.5">{user.email}</p>
                  </td>
                  <td className="px-4 py-3.5 hidden md:table-cell">
                    <span className={cn('text-xs px-2 py-0.5 rounded-full', {
                      'bg-yellow-900/30 text-yellow-400': user.subscription_status === 'premium',
                      'bg-blue-900/30 text-blue-400': user.subscription_status === 'basic',
                      'bg-ink-800 text-cream/40': user.subscription_status === 'free',
                    })}>
                      {user.subscription_status}
                    </span>
                  </td>
                  <td className="px-4 py-3.5 hidden lg:table-cell">
                    <span className="text-cream/50 text-xs">{formatCurrency(user.total_earnings)}</span>
                  </td>
                  <td className="px-4 py-3.5 hidden lg:table-cell">
                    <span className="text-cream/40 text-xs">{formatDate(user.created_at)}</span>
                  </td>
                  <td className="px-4 py-3.5">
                    <div className="flex items-center gap-1.5">
                      {user.is_creator && (
                        <span className="flex items-center gap-1 text-xs bg-parchment-900/30 text-parchment-400 px-2 py-0.5 rounded-full">
                          <Pen size={9} /> Creator
                        </span>
                      )}
                      {user.is_admin && (
                        <span className="flex items-center gap-1 text-xs bg-red-900/30 text-red-400 px-2 py-0.5 rounded-full">
                          <ShieldCheck size={9} /> Admin
                        </span>
                      )}
                    </div>
                  </td>
                  <td className="px-5 py-3.5">
                    <div className="flex items-center justify-end gap-2">
                      <button
                        onClick={() => toggleCreator(user.id, user.is_creator)}
                        className={cn(
                          'text-xs px-2.5 py-1 rounded-full transition-all border',
                          user.is_creator
                            ? 'border-parchment-700/50 text-parchment-400 hover:bg-red-900/20 hover:text-red-400 hover:border-red-700/50'
                            : 'border-ink-700 text-cream/40 hover:border-parchment-600 hover:text-parchment-400'
                        )}
                      >
                        {user.is_creator ? 'Revoke Creator' : 'Make Creator'}
                      </button>
                      <button
                        onClick={() => toggleAdmin(user.id, user.is_admin)}
                        className={cn(
                          'text-xs px-2.5 py-1 rounded-full transition-all border',
                          user.is_admin
                            ? 'border-red-700/50 text-red-400 hover:bg-red-900/20'
                            : 'border-ink-700 text-cream/40 hover:border-red-600 hover:text-red-400'
                        )}
                      >
                        {user.is_admin ? 'Revoke Admin' : 'Make Admin'}
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
              {filtered.length === 0 && (
                <tr>
                  <td colSpan={6} className="text-center text-cream/30 py-12 text-sm">No users found</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
