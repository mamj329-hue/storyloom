// src/components/admin/AdminContentTable.tsx
'use client'
import { useState } from 'react'
import { BookOpen, Play, Eye, Globe, EyeOff, Trash2, Lock, Unlock } from 'lucide-react'
import { formatCount, formatDate } from '@/lib/utils'
import { cn } from '@/lib/utils'
import toast from 'react-hot-toast'

interface ContentRow {
  id: string
  title: string
  genre: string | null
  is_published: boolean
  is_premium: boolean
  view_count: number
  created_at: string
  creator: { display_name: string | null; email: string } | null
}

interface Props {
  novels: ContentRow[]
  shorts: ContentRow[]
}

export default function AdminContentTable({ novels: initialNovels, shorts: initialShorts }: Props) {
  const [tab, setTab] = useState<'novels' | 'shorts'>('novels')
  const [novels, setNovels] = useState(initialNovels)
  const [shorts, setShorts] = useState(initialShorts)

  const items = tab === 'novels' ? novels : shorts
  const setItems = tab === 'novels' ? setNovels : setShorts

  const togglePublish = async (id: string, current: boolean) => {
    const endpoint = tab === 'novels' ? `/api/admin/novels/${id}` : `/api/admin/shorts/${id}`
    await fetch(endpoint, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ is_published: !current }),
    })
    setItems((prev: ContentRow[]) => prev.map(i => i.id === id ? { ...i, is_published: !current } : i))
    toast.success(!current ? 'Published' : 'Unpublished')
  }

  const handleDelete = async (id: string) => {
    if (!confirm('Delete this content permanently?')) return
    const endpoint = tab === 'novels' ? `/api/admin/novels/${id}` : `/api/admin/shorts/${id}`
    await fetch(endpoint, { method: 'DELETE' })
    setItems((prev: ContentRow[]) => prev.filter(i => i.id !== id))
    toast.success('Deleted')
  }

  return (
    <div>
      {/* Tabs */}
      <div className="flex gap-2 mb-6">
        {(['novels', 'shorts'] as const).map(t => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={cn(
              'flex items-center gap-2 px-5 py-2.5 rounded-full text-sm font-medium transition-all',
              tab === t ? 'bg-parchment-500 text-obsidian' : 'bg-ink-900 text-cream/60 border border-ink-700 hover:text-cream'
            )}
          >
            {t === 'novels' ? <BookOpen size={14} /> : <Play size={14} />}
            {t.charAt(0).toUpperCase() + t.slice(1)} ({(t === 'novels' ? novels : shorts).length})
          </button>
        ))}
      </div>

      {/* Table */}
      <div className="glass rounded-2xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-ink-800/60">
                <th className="text-left text-cream/40 font-medium px-5 py-3.5">Title</th>
                <th className="text-left text-cream/40 font-medium px-4 py-3.5 hidden md:table-cell">Creator</th>
                <th className="text-left text-cream/40 font-medium px-4 py-3.5 hidden sm:table-cell">Genre</th>
                <th className="text-left text-cream/40 font-medium px-4 py-3.5 hidden lg:table-cell">Views</th>
                <th className="text-left text-cream/40 font-medium px-4 py-3.5 hidden lg:table-cell">Date</th>
                <th className="text-left text-cream/40 font-medium px-4 py-3.5">Status</th>
                <th className="text-right text-cream/40 font-medium px-5 py-3.5">Actions</th>
              </tr>
            </thead>
            <tbody>
              {items.map((item, i) => (
                <tr
                  key={item.id}
                  className={cn('border-b border-ink-800/30 hover:bg-ink-900/40 transition-colors', i === items.length - 1 && 'border-0')}
                >
                  <td className="px-5 py-3.5">
                    <span className="text-cream font-medium line-clamp-1 max-w-[200px] block">{item.title}</span>
                  </td>
                  <td className="px-4 py-3.5 hidden md:table-cell">
                    <span className="text-cream/50 text-xs">{item.creator?.display_name || item.creator?.email || '—'}</span>
                  </td>
                  <td className="px-4 py-3.5 hidden sm:table-cell">
                    {item.genre && (
                      <span className="text-xs bg-ink-800 text-cream/50 px-2 py-0.5 rounded-full">{item.genre}</span>
                    )}
                  </td>
                  <td className="px-4 py-3.5 hidden lg:table-cell">
                    <span className="text-cream/50 flex items-center gap-1.5"><Eye size={11} />{formatCount(item.view_count)}</span>
                  </td>
                  <td className="px-4 py-3.5 hidden lg:table-cell">
                    <span className="text-cream/40 text-xs">{formatDate(item.created_at)}</span>
                  </td>
                  <td className="px-4 py-3.5">
                    <div className="flex items-center gap-2">
                      <span className={cn(
                        'text-xs px-2 py-0.5 rounded-full',
                        item.is_published ? 'bg-green-900/30 text-green-400' : 'bg-yellow-900/30 text-yellow-400'
                      )}>
                        {item.is_published ? 'Live' : 'Draft'}
                      </span>
                      {item.is_premium && <Lock size={11} className="text-parchment-500" />}
                    </div>
                  </td>
                  <td className="px-5 py-3.5">
                    <div className="flex items-center justify-end gap-2">
                      <button
                        onClick={() => togglePublish(item.id, item.is_published)}
                        className="text-cream/30 hover:text-parchment-400 transition-colors"
                        title={item.is_published ? 'Unpublish' : 'Publish'}
                      >
                        {item.is_published ? <EyeOff size={15} /> : <Globe size={15} />}
                      </button>
                      <button
                        onClick={() => handleDelete(item.id)}
                        className="text-cream/30 hover:text-red-400 transition-colors"
                        title="Delete"
                      >
                        <Trash2 size={15} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
              {items.length === 0 && (
                <tr>
                  <td colSpan={7} className="text-center text-cream/30 py-12 text-sm">No content found</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
