// src/app/dashboard/become-creator/page.tsx
'use client'
import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { Pen, Video, DollarSign, CheckCircle, Loader2 } from 'lucide-react'
import toast from 'react-hot-toast'

export default function BecomeCreatorPage() {
  const router = useRouter()
  const [loading, setLoading] = useState(false)

  const handleApply = async () => {
    setLoading(true)
    try {
      const res = await fetch('/api/creator/apply', { method: 'POST' })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error)
      toast.success('Creator account activated!')
      router.push('/dashboard/creator')
    } catch (err: any) {
      toast.error(err.message || 'Failed to activate')
    } finally {
      setLoading(false)
    }
  }

  return (
    <main className="min-h-screen pt-24 pb-16 flex items-center justify-center px-4">
      <div className="max-w-xl w-full text-center">
        <div className="w-20 h-20 bg-parchment-500/20 border border-parchment-600/30 rounded-full flex items-center justify-center mx-auto mb-6">
          <Pen size={32} className="text-parchment-400" />
        </div>
        <h1 className="font-display text-4xl font-bold text-cream mb-3">Become a Creator</h1>
        <p className="text-cream/50 text-lg mb-10 leading-relaxed">
          Share your stories with thousands of readers. Upload shorts, publish serialized novels,
          and earn from your content.
        </p>

        <div className="grid grid-cols-3 gap-4 mb-10">
          {[
            { icon: Video, label: 'Upload Shorts', sub: 'Vertical story videos' },
            { icon: Pen, label: 'Publish Novels', sub: 'Serialized chapters' },
            { icon: DollarSign, label: 'Earn Revenue', sub: 'Subscription share' },
          ].map(({ icon: Icon, label, sub }) => (
            <div key={label} className="glass rounded-2xl p-4 flex flex-col items-center gap-2">
              <Icon size={22} className="text-parchment-400" />
              <p className="text-cream text-sm font-semibold">{label}</p>
              <p className="text-cream/40 text-xs">{sub}</p>
            </div>
          ))}
        </div>

        <div className="space-y-3 mb-10 text-left">
          {[
            'Free to start — no upfront fees',
            'Upload unlimited novels and shorts',
            'Earn a share of subscription revenue',
            'Access to creator analytics dashboard',
          ].map(item => (
            <div key={item} className="flex items-center gap-3">
              <CheckCircle size={16} className="text-parchment-500 flex-shrink-0" />
              <span className="text-cream/70 text-sm">{item}</span>
            </div>
          ))}
        </div>

        <button
          onClick={handleApply}
          disabled={loading}
          className="btn-primary w-full text-base py-4 flex items-center justify-center gap-2"
        >
          {loading && <Loader2 size={18} className="animate-spin" />}
          Activate Creator Account
        </button>
      </div>
    </main>
  )
}
