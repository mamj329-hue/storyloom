// src/app/dashboard/creator/shorts/new/page.tsx
'use client'
import { useState, useRef } from 'react'
import { useRouter } from 'next/navigation'
import { Upload, X, Play, Loader2 } from 'lucide-react'
import { GENRES } from '@/types'
import toast from 'react-hot-toast'
import { cn } from '@/lib/utils'

export default function NewShortPage() {
  const router = useRouter()
  const fileRef = useRef<HTMLInputElement>(null)
  const [file, setFile] = useState<File | null>(null)
  const [preview, setPreview] = useState<string | null>(null)
  const [uploading, setUploading] = useState(false)
  const [saving, setSaving] = useState(false)
  const [uploadProgress, setUploadProgress] = useState(0)
  const [form, setForm] = useState({
    title: '', description: '', genre: '', tags: '', is_premium: false,
  })

  const handleFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0]
    if (!f) return
    if (f.size > 200 * 1024 * 1024) { toast.error('File must be under 200MB'); return }
    setFile(f)
    setPreview(URL.createObjectURL(f))
  }

  const handleSubmit = async (publish: boolean) => {
    if (!file) { toast.error('Please select a video'); return }
    if (!form.title.trim()) { toast.error('Title is required'); return }

    setUploading(true)
    try {
      // Upload video
      const fd = new FormData()
      fd.append('file', file)
      const uploadRes = await fetch('/api/upload/video', { method: 'POST', body: fd })
      const uploadData = await uploadRes.json()
      if (!uploadRes.ok) throw new Error(uploadData.error)

      setUploading(false)
      setSaving(true)

      // Save short
      const res = await fetch('/api/creator/shorts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...form,
          tags: form.tags.split(',').map(t => t.trim()).filter(Boolean),
          video_url: uploadData.url,
          thumbnail_url: uploadData.thumbnail_url,
          cloudinary_public_id: uploadData.public_id,
          duration_seconds: uploadData.duration,
          is_published: publish,
        }),
      })

      if (!res.ok) throw new Error('Failed to save')
      toast.success(publish ? 'Short published!' : 'Saved as draft')
      router.push('/dashboard/creator')
    } catch (err: any) {
      toast.error(err.message || 'Upload failed')
    } finally {
      setUploading(false)
      setSaving(false)
    }
  }

  return (
    <main className="min-h-screen pt-20 pb-16">
      <div className="max-w-3xl mx-auto px-4">
        <div className="mb-8">
          <h1 className="font-display text-3xl font-bold text-cream">Upload Short</h1>
          <p className="text-cream/50 mt-1">Share a vertical story video</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Video upload */}
          <div>
            <div
              className={cn(
                'relative aspect-[9/16] rounded-2xl border-2 border-dashed transition-all cursor-pointer overflow-hidden',
                file ? 'border-parchment-600/50' : 'border-ink-700 hover:border-ink-500'
              )}
              onClick={() => fileRef.current?.click()}
            >
              {preview ? (
                <>
                  <video src={preview} className="w-full h-full object-cover" />
                  <button
                    className="absolute top-3 right-3 bg-black/60 rounded-full p-1.5"
                    onClick={(e) => { e.stopPropagation(); setFile(null); setPreview(null) }}
                  >
                    <X size={16} className="text-white" />
                  </button>
                  <div className="absolute inset-0 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity bg-black/30">
                    <Play size={40} className="text-white" fill="white" />
                  </div>
                </>
              ) : (
                <div className="flex flex-col items-center justify-center h-full gap-3 text-cream/40">
                  <Upload size={36} />
                  <p className="text-sm">Click to upload video</p>
                  <p className="text-xs">MP4, MOV — max 200MB</p>
                </div>
              )}
            </div>
            <input ref={fileRef} type="file" accept="video/*" className="hidden" onChange={handleFile} />
          </div>

          {/* Form */}
          <div className="flex flex-col gap-4">
            <div>
              <label className="text-cream/70 text-sm mb-1.5 block">Title *</label>
              <input
                value={form.title}
                onChange={e => setForm(f => ({ ...f, title: e.target.value }))}
                placeholder="A gripping story title..."
                className="w-full bg-ink-900 border border-ink-700 focus:border-parchment-600 rounded-xl px-4 py-3 text-cream text-sm outline-none transition-colors"
              />
            </div>

            <div>
              <label className="text-cream/70 text-sm mb-1.5 block">Description</label>
              <textarea
                value={form.description}
                onChange={e => setForm(f => ({ ...f, description: e.target.value }))}
                placeholder="What's this video about?"
                rows={3}
                className="w-full bg-ink-900 border border-ink-700 focus:border-parchment-600 rounded-xl px-4 py-3 text-cream text-sm outline-none transition-colors resize-none"
              />
            </div>

            <div>
              <label className="text-cream/70 text-sm mb-1.5 block">Genre</label>
              <select
                value={form.genre}
                onChange={e => setForm(f => ({ ...f, genre: e.target.value }))}
                className="w-full bg-ink-900 border border-ink-700 focus:border-parchment-600 rounded-xl px-4 py-3 text-cream text-sm outline-none"
              >
                <option value="">Select genre</option>
                {GENRES.map(g => <option key={g} value={g}>{g}</option>)}
              </select>
            </div>

            <div>
              <label className="text-cream/70 text-sm mb-1.5 block">Tags (comma separated)</label>
              <input
                value={form.tags}
                onChange={e => setForm(f => ({ ...f, tags: e.target.value }))}
                placeholder="romance, drama, office"
                className="w-full bg-ink-900 border border-ink-700 focus:border-parchment-600 rounded-xl px-4 py-3 text-cream text-sm outline-none transition-colors"
              />
            </div>

            <label className="flex items-center gap-3 cursor-pointer">
              <div
                className={cn(
                  'w-11 h-6 rounded-full transition-colors relative',
                  form.is_premium ? 'bg-parchment-500' : 'bg-ink-700'
                )}
                onClick={() => setForm(f => ({ ...f, is_premium: !f.is_premium }))}
              >
                <div className={cn(
                  'absolute top-0.5 w-5 h-5 rounded-full bg-white shadow transition-transform',
                  form.is_premium ? 'translate-x-5 left-0.5' : 'left-0.5'
                )} />
              </div>
              <span className="text-cream/70 text-sm">Premium only</span>
            </label>

            {/* Upload progress */}
            {(uploading || saving) && (
              <div className="space-y-2">
                <div className="h-1.5 bg-ink-800 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-parchment-500 transition-all duration-300"
                    style={{ width: uploading ? '60%' : '95%' }}
                  />
                </div>
                <p className="text-cream/40 text-xs text-center">
                  {uploading ? 'Uploading video...' : 'Saving...'}
                </p>
              </div>
            )}

            <div className="flex gap-3 mt-2">
              <button
                onClick={() => handleSubmit(false)}
                disabled={uploading || saving}
                className="btn-ghost flex-1 flex items-center justify-center gap-2"
              >
                {saving && <Loader2 size={14} className="animate-spin" />}
                Save Draft
              </button>
              <button
                onClick={() => handleSubmit(true)}
                disabled={uploading || saving}
                className="btn-primary flex-1 flex items-center justify-center gap-2"
              >
                {(uploading || saving) && <Loader2 size={14} className="animate-spin" />}
                Publish
              </button>
            </div>
          </div>
        </div>
      </div>
    </main>
  )
}
