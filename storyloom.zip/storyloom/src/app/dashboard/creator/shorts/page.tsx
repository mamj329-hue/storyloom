// src/app/dashboard/creator/shorts/page.tsx
import { currentUser } from '@clerk/nextjs/server'
import { redirect } from 'next/navigation'
import { createAdminClient } from '@/lib/supabase/server'
import Link from 'next/link'
import { Play, Plus, Eye, Heart, Lock, Globe, EyeOff, ArrowLeft } from 'lucide-react'
import { formatCount, formatDate } from '@/lib/utils'
import { cn } from '@/lib/utils'

export default async function CreatorShortsPage() {
  const clerkUser = await currentUser()
  if (!clerkUser) redirect('/auth/sign-in')

  const supabase = createAdminClient()
  const { data: user } = await supabase
    .from('users').select('id,is_creator').eq('clerk_id', clerkUser.id).single()
  if (!user?.is_creator) redirect('/dashboard/become-creator')

  const { data: shorts } = await supabase
    .from('shorts')
    .select('*')
    .eq('creator_id', user.id)
    .order('created_at', { ascending: false })

  return (
    <main className="min-h-screen pt-20 pb-16">
      <div className="max-w-5xl mx-auto px-4">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-3">
            <Link href="/dashboard/creator" className="text-cream/40 hover:text-cream/70 transition-colors">
              <ArrowLeft size={18} />
            </Link>
            <div>
              <h1 className="font-display text-2xl font-bold text-cream">My Shorts</h1>
              <p className="text-cream/40 text-sm">{shorts?.length || 0} videos</p>
            </div>
          </div>
          <Link href="/dashboard/creator/shorts/new" className="btn-primary text-sm flex items-center gap-2">
            <Plus size={15} /> Upload Short
          </Link>
        </div>

        <div className="space-y-2">
          {shorts?.map(short => (
            <div key={short.id} className="glass rounded-xl p-4 flex items-center gap-4">
              {/* Thumbnail */}
              <div className="relative w-14 h-20 rounded-lg overflow-hidden bg-ink-900 flex-shrink-0">
                {short.thumbnail_url ? (
                  <img src={short.thumbnail_url} alt="" className="w-full h-full object-cover" />
                ) : (
                  <div className="w-full h-full flex items-center justify-center">
                    <Play size={16} className="text-parchment-700" />
                  </div>
                )}
              </div>

              {/* Info */}
              <div className="flex-1 min-w-0">
                <p className="text-cream font-medium text-sm line-clamp-1">{short.title}</p>
                <div className="flex flex-wrap items-center gap-3 mt-1">
                  {short.genre && (
                    <span className="text-xs bg-ink-800 text-cream/40 px-2 py-0.5 rounded-full">{short.genre}</span>
                  )}
                  <span className="text-cream/30 text-xs">{formatDate(short.created_at)}</span>
                  {short.duration_seconds && (
                    <span className="text-cream/30 text-xs">{Math.round(short.duration_seconds)}s</span>
                  )}
                </div>
                <div className="flex items-center gap-4 mt-1.5 text-cream/40 text-xs">
                  <span className="flex items-center gap-1"><Eye size={10} />{formatCount(short.view_count)}</span>
                  <span className="flex items-center gap-1"><Heart size={10} />{formatCount(short.like_count)}</span>
                  {short.is_premium && <span className="flex items-center gap-1 text-parchment-500"><Lock size={10} />Premium</span>}
                </div>
              </div>

              {/* Status + Actions */}
              <div className="flex items-center gap-3 flex-shrink-0">
                <span className={cn(
                  'text-xs px-2.5 py-1 rounded-full flex items-center gap-1',
                  short.is_published
                    ? 'bg-green-900/30 text-green-400'
                    : 'bg-yellow-900/30 text-yellow-400'
                )}>
                  {short.is_published ? <><Globe size={9} /> Live</> : <><EyeOff size={9} /> Draft</>}
                </span>
                <Link
                  href={`/dashboard/creator/shorts/${short.id}/edit`}
                  className="text-cream/40 hover:text-parchment-400 text-xs transition-colors"
                >
                  Edit
                </Link>
              </div>
            </div>
          ))}

          {!shorts?.length && (
            <div className="text-center py-20">
              <Play size={40} className="mx-auto mb-3 text-cream/20" />
              <p className="text-cream/40 text-sm mb-4">No shorts uploaded yet</p>
              <Link href="/dashboard/creator/shorts/new" className="btn-primary text-sm">
                Upload your first short
              </Link>
            </div>
          )}
        </div>
      </div>
    </main>
  )
}
