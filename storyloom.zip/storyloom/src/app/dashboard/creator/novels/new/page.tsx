// src/app/dashboard/creator/novels/new/page.tsx
'use client'
import { useState, useRef } from 'react'
import { useRouter } from 'next/navigation'
import Image from 'next/image'
import { Upload, X, BookOpen, Loader2 } from 'lucide-react'
import { GENRES } from '@/types'
import toast from 'react-hot-toast'
import { cn } from '@/lib/utils'

export default function NewNovelPage() {
  const router = useRouter()
  const coverRef = useRef<HTMLInputElement>(null)
  const [coverFile, setCoverFile] = useState<File | null>(null)
  const [coverPreview, setCoverPreview] = useState<string | null>(null)
  const [uploading, setUploading] = useState(false)
  const [saving, setSaving] = useState(false)
  const [form, setForm] = useState({
    title: '',
    synopsis: '',
    genre: '',
    tags: '',
    status: 'ongoing',
    is_premium: false,
  })

  const handleCover = (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0]
    if (!f) return
    if (f.size > 10 * 1024 * 1024) { toast.error('Cover must be under 10MB'); return }
    setCoverFile(f)
    setCoverPreview(URL.createObjectURL(f))
  }

  const handleSubmit = async (publish: boolean) => {
    if (!form.title.trim()) { toast.error('Title is required'); return }
    if (!form.genre) { toast.error('Genre is required'); return }

    setSaving(true)
    try {
      let cover_url = null
      let cloudinary_public_id = null

      if (coverFile) {
        setUploading(true)
        const fd = new FormData()
        fd.append('file', coverFile)
        fd.append('folder', 'storyloom/covers')
        const uploadRes = await fetch('/api/upload/image', { method: 'POST', body: fd })
        const uploadData = await uploadRes.json()
        if (!uploadRes.ok) throw new Error(uploadData.error)
        cover_url = uploadData.url
        cloudinary_public_id = uploadData.public_id
        setUploading(false)
      }

      const res = await fetch('/api/creator/novels', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...form,
          tags: form.tags.split(',').map(t => t.trim()).filter(Boolean),
          cover_url,
          cloudinary_public_id,
          is_published: publish,
        }),
      })

      const data = await res.json()
      if (!res.ok) throw new Error(data.error)

      toast.success(publish ? 'Novel published!' : 'Saved as draft')
      router.push(`/dashboard/creator/novels/${data.novel.id}`)
    } catch (err: any) {
      toast.error(err.message || 'Failed to save novel')
    } finally {
      setSaving(false)
      setUploading(false)
    }
  }

  return (
    <main className="min-h-screen pt-20 pb-16">
      <div className="max-w-4xl mx-auto px-4">
        <div className="mb-8">
          <h1 className="font-display text-3xl font-bold text-cream">Create Novel</h1>
          <p className="text-cream/50 mt-1">Set up your serialized story</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Cover upload */}
          <div className="md:col-span-1">
            <label className="text-cream/70 text-sm mb-2 block">Cover Image</label>
            <div
              className={cn(
                'relative aspect-[2/3] rounded-2xl border-2 border-dashed transition-all cursor-pointer overflow-hidden',
                coverFile ? 'border-parchment-600/50' : 'border-ink-700 hover:border-ink-500'
              )}
              onClick={() => coverRef.current?.click()}
            >
              {coverPreview ? (
                <>
                  <Image src={coverPreview} alt="Cover preview" fill className="object-cover" />
                  <button
                    className="absolute top-2 right-2 bg-black/60 rounded-full p-1.5 z-10"
                    onClick={e => { e.stopPropagation(); setCoverFile(null); setCoverPreview(null) }}
                  >
                    <X size={14} className="text-white" />
                  </button>
                </>
              ) : (
                <div className="flex flex-col items-center justify-center h-full gap-3 text-cream/40">
                  <Upload size={28} />
                  <p className="text-xs text-center px-4">Click to upload cover<br />Recommended: 800×1200</p>
                </div>
              )}
            </div>
            <input ref={coverRef} type="file" accept="image/*" className="hidden" onChange={handleCover} />
          </div>

          {/* Form fields */}
          <div className="md:col-span-2 flex flex-col gap-5">
            <div>
              <label className="text-cream/70 text-sm mb-1.5 block">Title *</label>
              <input
                value={form.title}
                onChange={e => setForm(f => ({ ...f, title: e.target.value }))}
                placeholder="The title of your masterpiece..."
                className="w-full bg-ink-900 border border-ink-700 focus:border-parchment-600 rounded-xl px-4 py-3 text-cream text-sm outline-none transition-colors"
              />
            </div>

            <div>
              <label className="text-cream/70 text-sm mb-1.5 block">Synopsis</label>
              <textarea
                value={form.synopsis}
                onChange={e => setForm(f => ({ ...f, synopsis: e.target.value }))}
                placeholder="Hook readers with a compelling description..."
                rows={5}
                className="w-full bg-ink-900 border border-ink-700 focus:border-parchment-600 rounded-xl px-4 py-3 text-cream text-sm outline-none transition-colors resize-none"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-cream/70 text-sm mb-1.5 block">Genre *</label>
                <select
                  value={form.genre}
                  onChange={e => setForm(f => ({ ...f, genre: e.target.value }))}
                  className="w-full bg-ink-900 border border-ink-700 focus:border-parchment-600 rounded-xl px-4 py-3 text-cream text-sm outline-none"
                >
                  <option value="">Select genre</option>
                  {GENRES.map(g => <option key={g} value={g}>{g}</option>)}
                </select>
              </div>

              <div>
                <label className="text-cream/70 text-sm mb-1.5 block">Status</label>
                <select
                  value={form.status}
                  onChange={e => setForm(f => ({ ...f, status: e.target.value }))}
                  className="w-full bg-ink-900 border border-ink-700 focus:border-parchment-600 rounded-xl px-4 py-3 text-cream text-sm outline-none"
                >
                  <option value="ongoing">Ongoing</option>
                  <option value="completed">Completed</option>
                  <option value="hiatus">Hiatus</option>
                </select>
              </div>
            </div>

            <div>
              <label className="text-cream/70 text-sm mb-1.5 block">Tags (comma separated)</label>
              <input
                value={form.tags}
                onChange={e => setForm(f => ({ ...f, tags: e.target.value }))}
                placeholder="billionaire, revenge, slow burn"
                className="w-full bg-ink-900 border border-ink-700 focus:border-parchment-600 rounded-xl px-4 py-3 text-cream text-sm outline-none transition-colors"
              />
            </div>

            <label className="flex items-center gap-3 cursor-pointer">
              <div
                className={cn(
                  'w-11 h-6 rounded-full transition-colors relative flex-shrink-0',
                  form.is_premium ? 'bg-parchment-500' : 'bg-ink-700'
                )}
                onClick={() => setForm(f => ({ ...f, is_premium: !f.is_premium }))}
              >
                <div className={cn(
                  'absolute top-0.5 w-5 h-5 rounded-full bg-white shadow transition-transform',
                  form.is_premium ? 'translate-x-5 left-0.5' : 'left-0.5'
                )} />
              </div>
              <div>
                <p className="text-cream/70 text-sm">Premium novel</p>
                <p className="text-cream/30 text-xs">Premium chapters require subscription</p>
              </div>
            </label>

            <div className="flex gap-3 pt-2">
              <button
                onClick={() => handleSubmit(false)}
                disabled={saving}
                className="btn-ghost flex-1 flex items-center justify-center gap-2"
              >
                {saving && !uploading && <Loader2 size={14} className="animate-spin" />}
                Save Draft
              </button>
              <button
                onClick={() => handleSubmit(true)}
                disabled={saving}
                className="btn-primary flex-1 flex items-center justify-center gap-2"
              >
                {saving && <Loader2 size={14} className="animate-spin" />}
                {uploading ? 'Uploading cover...' : 'Publish Novel'}
              </button>
            </div>
          </div>
        </div>
      </div>
    </main>
  )
}
