// src/app/dashboard/creator/novels/[novelId]/page.tsx
'use client'
import { useEffect, useState } from 'react'
import { useParams, useRouter } from 'next/navigation'
import Link from 'next/link'
import Image from 'next/image'
import {
  BookOpen, Plus, Eye, Lock, CheckCircle,
  Edit3, Trash2, Globe, EyeOff, Loader2, ArrowLeft
} from 'lucide-react'
import { formatCount, formatDate } from '@/lib/utils'
import { cn } from '@/lib/utils'
import toast from 'react-hot-toast'
import type { Novel, Chapter } from '@/types'

export default function CreatorNovelPage() {
  const { novelId } = useParams<{ novelId: string }>()
  const router = useRouter()
  const [novel, setNovel] = useState<Novel | null>(null)
  const [chapters, setChapters] = useState<Chapter[]>([])
  const [loading, setLoading] = useState(true)
  const [showChapterForm, setShowChapterForm] = useState(false)
  const [savingChapter, setSavingChapter] = useState(false)
  const [chapterForm, setChapterForm] = useState({
    title: '', content: '', is_premium: false, is_published: false,
  })

  useEffect(() => {
    const load = async () => {
      const [novelRes, chaptersRes] = await Promise.all([
        fetch(`/api/creator/novels/${novelId}`),
        fetch(`/api/creator/novels/${novelId}/chapters`),
      ])
      if (novelRes.ok) setNovel(await novelRes.json().then(d => d.novel))
      if (chaptersRes.ok) setChapters(await chaptersRes.json().then(d => d.chapters || []))
      setLoading(false)
    }
    load()
  }, [novelId])

  const handleSaveChapter = async (publish: boolean) => {
    if (!chapterForm.title.trim()) { toast.error('Chapter title required'); return }
    if (!chapterForm.content.trim()) { toast.error('Chapter content required'); return }
    setSavingChapter(true)
    try {
      const res = await fetch(`/api/creator/novels/${novelId}/chapters`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...chapterForm, is_published: publish }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error)
      setChapters(prev => [...prev, data.chapter])
      setChapterForm({ title: '', content: '', is_premium: false, is_published: false })
      setShowChapterForm(false)
      toast.success(publish ? 'Chapter published!' : 'Chapter saved as draft')
    } catch (err: any) {
      toast.error(err.message || 'Failed to save chapter')
    } finally {
      setSavingChapter(false)
    }
  }

  const togglePublish = async (chapterId: string, current: boolean) => {
    await fetch(`/api/creator/novels/${novelId}/chapters/${chapterId}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ is_published: !current }),
    })
    setChapters(prev => prev.map(c => c.id === chapterId ? { ...c, is_published: !current } : c))
    toast.success(!current ? 'Chapter published' : 'Chapter unpublished')
  }

  if (loading) {
    return (
      <div className="min-h-screen pt-20 flex items-center justify-center">
        <Loader2 size={32} className="animate-spin text-parchment-500" />
      </div>
    )
  }

  if (!novel) {
    return (
      <div className="min-h-screen pt-20 flex items-center justify-center text-cream/40">
        Novel not found
      </div>
    )
  }

  return (
    <main className="min-h-screen pt-20 pb-16">
      <div className="max-w-4xl mx-auto px-4">
        {/* Back */}
        <Link href="/dashboard/creator" className="flex items-center gap-2 text-cream/40 hover:text-cream/70 text-sm mb-6 transition-colors">
          <ArrowLeft size={15} /> Back to Dashboard
        </Link>

        {/* Novel header */}
        <div className="flex gap-5 mb-10 glass rounded-2xl p-6">
          <div className="relative w-20 h-28 flex-shrink-0 rounded-xl overflow-hidden bg-ink-900">
            {novel.cover_url
              ? <Image src={novel.cover_url} alt={novel.title} fill className="object-cover" />
              : <div className="w-full h-full flex items-center justify-center"><BookOpen size={24} className="text-parchment-700" /></div>
            }
          </div>
          <div className="flex-1 min-w-0">
            <h1 className="font-display text-2xl font-bold text-cream mb-1 truncate">{novel.title}</h1>
            <div className="flex flex-wrap items-center gap-3 mb-3">
              <span className="text-xs bg-parchment-500/20 text-parchment-400 px-2 py-0.5 rounded-full">{novel.genre}</span>
              <span className={cn('text-xs px-2 py-0.5 rounded-full', novel.is_published ? 'bg-green-900/30 text-green-400' : 'bg-yellow-900/30 text-yellow-400')}>
                {novel.is_published ? 'Published' : 'Draft'}
              </span>
              {novel.is_premium && <span className="text-xs bg-parchment-900/40 text-parchment-400 px-2 py-0.5 rounded-full">Premium</span>}
            </div>
            <div className="flex gap-4 text-cream/40 text-xs">
              <span className="flex items-center gap-1"><Eye size={11} />{formatCount(novel.view_count)} views</span>
              <span>{novel.total_chapters} chapters</span>
            </div>
          </div>
          <Link href={`/dashboard/creator/novels/${novelId}/edit`} className="flex-shrink-0 btn-ghost text-sm flex items-center gap-2 self-start">
            <Edit3 size={14} /> Edit
          </Link>
        </div>

        {/* Chapter list */}
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-display text-xl font-semibold text-cream">
            Chapters <span className="text-cream/30 font-normal text-base ml-1">({chapters.length})</span>
          </h2>
          <button
            onClick={() => setShowChapterForm(true)}
            className="btn-primary text-sm flex items-center gap-2"
          >
            <Plus size={15} /> Add Chapter
          </button>
        </div>

        {/* Chapter form */}
        {showChapterForm && (
          <div className="glass rounded-2xl p-6 mb-6 border border-parchment-700/30">
            <h3 className="font-semibold text-cream mb-4">
              New Chapter {chapters.length + 1}
            </h3>
            <div className="space-y-4">
              <input
                value={chapterForm.title}
                onChange={e => setChapterForm(f => ({ ...f, title: e.target.value }))}
                placeholder="Chapter title..."
                className="w-full bg-ink-900 border border-ink-700 focus:border-parchment-600 rounded-xl px-4 py-3 text-cream text-sm outline-none transition-colors"
              />
              <textarea
                value={chapterForm.content}
                onChange={e => setChapterForm(f => ({ ...f, content: e.target.value }))}
                placeholder="Write your chapter here..."
                rows={14}
                className="w-full bg-ink-900 border border-ink-700 focus:border-parchment-600 rounded-xl px-4 py-3 text-cream text-sm outline-none transition-colors resize-none font-body leading-relaxed"
              />
              <div className="flex items-center gap-6">
                <label className="flex items-center gap-2 cursor-pointer text-sm text-cream/60">
                  <input
                    type="checkbox"
                    checked={chapterForm.is_premium}
                    onChange={e => setChapterForm(f => ({ ...f, is_premium: e.target.checked }))}
                    className="accent-parchment-500"
                  />
                  Premium chapter
                </label>
                <span className="text-cream/30 text-xs">
                  {chapterForm.content.trim()
                    ? `~${Math.ceil(chapterForm.content.trim().split(/\s+/).length / 250)} min read`
                    : '0 words'}
                </span>
              </div>
              <div className="flex gap-3">
                <button
                  onClick={() => setShowChapterForm(false)}
                  className="btn-ghost flex-1"
                  disabled={savingChapter}
                >
                  Cancel
                </button>
                <button
                  onClick={() => handleSaveChapter(false)}
                  disabled={savingChapter}
                  className="btn-ghost flex-1 flex items-center justify-center gap-2"
                >
                  {savingChapter && <Loader2 size={13} className="animate-spin" />}
                  Save Draft
                </button>
                <button
                  onClick={() => handleSaveChapter(true)}
                  disabled={savingChapter}
                  className="btn-primary flex-1 flex items-center justify-center gap-2"
                >
                  {savingChapter && <Loader2 size={13} className="animate-spin" />}
                  Publish
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Chapter rows */}
        <div className="space-y-2">
          {chapters.map(ch => (
            <div key={ch.id} className="glass rounded-xl px-4 py-3.5 flex items-center gap-3">
              <span className="text-parchment-600/50 text-xs font-mono w-7 text-right flex-shrink-0">{ch.chapter_number}</span>
              <div className="flex-1 min-w-0">
                <span className="text-cream text-sm line-clamp-1">{ch.title}</span>
                <div className="flex items-center gap-3 mt-0.5 text-cream/30 text-xs">
                  <span>{Math.ceil((ch.word_count || 0) / 250)} min</span>
                  <span className="flex items-center gap-1"><Eye size={10} />{formatCount(ch.view_count)}</span>
                  <span>{formatDate(ch.created_at)}</span>
                </div>
              </div>
              <div className="flex items-center gap-2 flex-shrink-0">
                {ch.is_premium && <Lock size={12} className="text-parchment-500" />}
                <button
                  onClick={() => togglePublish(ch.id, ch.is_published)}
                  className={cn(
                    'text-xs px-2.5 py-1 rounded-full transition-colors flex items-center gap-1',
                    ch.is_published
                      ? 'bg-green-900/30 text-green-400 hover:bg-red-900/30 hover:text-red-400'
                      : 'bg-ink-800 text-cream/40 hover:bg-green-900/30 hover:text-green-400'
                  )}
                >
                  {ch.is_published
                    ? <><Globe size={10} /> Published</>
                    : <><EyeOff size={10} /> Draft</>
                  }
                </button>
                <Link
                  href={`/dashboard/creator/novels/${novelId}/chapters/${ch.id}/edit`}
                  className="text-cream/30 hover:text-parchment-400 transition-colors"
                >
                  <Edit3 size={14} />
                </Link>
              </div>
            </div>
          ))}
          {chapters.length === 0 && !showChapterForm && (
            <div className="text-center py-16 text-cream/30">
              <BookOpen size={40} className="mx-auto mb-3 opacity-30" />
              <p className="text-sm">No chapters yet. Add your first chapter above.</p>
            </div>
          )}
        </div>
      </div>
    </main>
  )
}
