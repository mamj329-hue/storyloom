// src/app/dashboard/creator/analytics/page.tsx
import { currentUser } from '@clerk/nextjs/server'
import { redirect } from 'next/navigation'
import { createAdminClient } from '@/lib/supabase/server'
import { formatCount, formatCurrency, formatDate } from '@/lib/utils'
import Link from 'next/link'
import { ArrowLeft, TrendingUp, Eye, Heart, MessageCircle, DollarSign } from 'lucide-react'

export default async function CreatorAnalyticsPage() {
  const clerkUser = await currentUser()
  if (!clerkUser) redirect('/auth/sign-in')

  const supabase = createAdminClient()
  const { data: user } = await supabase
    .from('users').select('id,is_creator,total_earnings').eq('clerk_id', clerkUser.id).single()
  if (!user?.is_creator) redirect('/dashboard/become-creator')

  const [{ data: shorts }, { data: novels }, { data: earnings }] = await Promise.all([
    supabase.from('shorts')
      .select('id,title,view_count,like_count,comment_count,created_at')
      .eq('creator_id', user.id)
      .order('view_count', { ascending: false })
      .limit(10),
    supabase.from('novels')
      .select('id,title,slug,view_count,like_count,total_chapters,rating,created_at')
      .eq('creator_id', user.id)
      .order('view_count', { ascending: false })
      .limit(10),
    supabase.from('creator_earnings')
      .select('*')
      .eq('creator_id', user.id)
      .order('created_at', { ascending: false })
      .limit(20),
  ])

  const totalViews = [
    ...(shorts || []).map(s => s.view_count),
    ...(novels || []).map(n => n.view_count),
  ].reduce((a, b) => a + b, 0)

  const totalLikes = [
    ...(shorts || []).map(s => s.like_count),
    ...(novels || []).map(n => n.like_count),
  ].reduce((a, b) => a + b, 0)

  const totalComments = (shorts || []).reduce((a, s) => a + s.comment_count, 0)

  return (
    <main className="min-h-screen pt-20 pb-16">
      <div className="max-w-5xl mx-auto px-4">
        <div className="flex items-center gap-3 mb-8">
          <Link href="/dashboard/creator" className="text-cream/40 hover:text-cream/70 transition-colors">
            <ArrowLeft size={18} />
          </Link>
          <div>
            <h1 className="font-display text-2xl font-bold text-cream">Analytics</h1>
            <p className="text-cream/40 text-sm">Your content performance</p>
          </div>
        </div>

        {/* Summary stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-10">
          {[
            { label: 'Total Views', value: formatCount(totalViews), icon: Eye, color: 'text-blue-400' },
            { label: 'Total Likes', value: formatCount(totalLikes), icon: Heart, color: 'text-red-400' },
            { label: 'Comments', value: formatCount(totalComments), icon: MessageCircle, color: 'text-purple-400' },
            { label: 'Earnings', value: formatCurrency(user.total_earnings), icon: DollarSign, color: 'text-green-400' },
          ].map(({ label, value, icon: Icon, color }) => (
            <div key={label} className="glass rounded-2xl p-5">
              <Icon size={20} className={`${color} mb-3`} />
              <p className="text-cream text-xl font-bold">{value}</p>
              <p className="text-cream/40 text-xs mt-1">{label}</p>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Top Shorts */}
          <section>
            <h2 className="font-display text-lg font-semibold text-cream mb-4 flex items-center gap-2">
              <TrendingUp size={16} className="text-parchment-500" /> Top Shorts
            </h2>
            <div className="space-y-2">
              {shorts?.map((short, i) => (
                <div key={short.id} className="glass rounded-xl px-4 py-3 flex items-center gap-3">
                  <span className="text-parchment-600/40 text-xs font-mono w-5 text-right">#{i + 1}</span>
                  <div className="flex-1 min-w-0">
                    <p className="text-cream text-sm line-clamp-1">{short.title}</p>
                    <div className="flex gap-3 mt-0.5 text-cream/30 text-xs">
                      <span className="flex items-center gap-1"><Eye size={9} />{formatCount(short.view_count)}</span>
                      <span className="flex items-center gap-1"><Heart size={9} />{formatCount(short.like_count)}</span>
                    </div>
                  </div>
                </div>
              ))}
              {!shorts?.length && <p className="text-cream/30 text-sm text-center py-6">No shorts data yet</p>}
            </div>
          </section>

          {/* Top Novels */}
          <section>
            <h2 className="font-display text-lg font-semibold text-cream mb-4 flex items-center gap-2">
              <TrendingUp size={16} className="text-parchment-500" /> Top Novels
            </h2>
            <div className="space-y-2">
              {novels?.map((novel, i) => (
                <div key={novel.id} className="glass rounded-xl px-4 py-3 flex items-center gap-3">
                  <span className="text-parchment-600/40 text-xs font-mono w-5 text-right">#{i + 1}</span>
                  <div className="flex-1 min-w-0">
                    <p className="text-cream text-sm line-clamp-1">{novel.title}</p>
                    <div className="flex gap-3 mt-0.5 text-cream/30 text-xs">
                      <span className="flex items-center gap-1"><Eye size={9} />{formatCount(novel.view_count)}</span>
                      <span>{novel.total_chapters} ch.</span>
                      <span>★ {novel.rating.toFixed(1)}</span>
                    </div>
                  </div>
                </div>
              ))}
              {!novels?.length && <p className="text-cream/30 text-sm text-center py-6">No novels data yet</p>}
            </div>
          </section>
        </div>

        {/* Earnings history */}
        {earnings && earnings.length > 0 && (
          <section className="mt-10">
            <h2 className="font-display text-lg font-semibold text-cream mb-4 flex items-center gap-2">
              <DollarSign size={16} className="text-parchment-500" /> Earnings History
            </h2>
            <div className="glass rounded-2xl overflow-hidden">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-ink-800/60">
                    <th className="text-left text-cream/40 font-medium px-5 py-3">Type</th>
                    <th className="text-left text-cream/40 font-medium px-4 py-3">Description</th>
                    <th className="text-left text-cream/40 font-medium px-4 py-3">Date</th>
                    <th className="text-right text-cream/40 font-medium px-5 py-3">Amount</th>
                  </tr>
                </thead>
                <tbody>
                  {earnings.map((e, i) => (
                    <tr key={e.id} className={i < earnings.length - 1 ? 'border-b border-ink-800/30' : ''}>
                      <td className="px-5 py-3">
                        <span className="text-xs bg-ink-800 text-cream/50 px-2 py-0.5 rounded-full capitalize">
                          {e.source_type.replace('_', ' ')}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-cream/60 text-xs">{e.description || '—'}</td>
                      <td className="px-4 py-3 text-cream/40 text-xs">{formatDate(e.created_at)}</td>
                      <td className="px-5 py-3 text-right">
                        <span className="text-green-400 font-semibold text-sm">{formatCurrency(e.amount)}</span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>
        )}
      </div>
    </main>
  )
}
