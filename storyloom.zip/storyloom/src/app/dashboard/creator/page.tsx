// src/app/dashboard/creator/page.tsx
import { currentUser } from '@clerk/nextjs/server'
import { redirect } from 'next/navigation'
import { createAdminClient } from '@/lib/supabase/server'
import { formatCurrency, formatCount } from '@/lib/utils'
import Link from 'next/link'
import {
  BookOpen, Play, TrendingUp, DollarSign,
  PlusCircle, Eye, Heart, Users
} from 'lucide-react'

export default async function CreatorDashboard() {
  const clerkUser = await currentUser()
  if (!clerkUser) redirect('/auth/sign-in')

  const supabase = createAdminClient()
  const { data: user } = await supabase
    .from('users').select('*').eq('clerk_id', clerkUser.id).single()

  if (!user?.is_creator) redirect('/dashboard/become-creator')

  // Fetch stats
  const [{ count: shortCount }, { count: novelCount }, { data: shorts }, { data: novels }] = await Promise.all([
    supabase.from('shorts').select('*', { count: 'exact', head: true }).eq('creator_id', user.id),
    supabase.from('novels').select('*', { count: 'exact', head: true }).eq('creator_id', user.id),
    supabase.from('shorts').select('id,title,view_count,like_count,is_published,created_at')
      .eq('creator_id', user.id).order('created_at', { ascending: false }).limit(5),
    supabase.from('novels').select('id,title,slug,view_count,like_count,total_chapters,is_published,created_at')
      .eq('creator_id', user.id).order('created_at', { ascending: false }).limit(5),
  ])

  const totalViews = [
    ...(shorts || []).map(s => s.view_count),
    ...(novels || []).map(n => n.view_count),
  ].reduce((a, b) => a + b, 0)

  const totalLikes = [
    ...(shorts || []).map(s => s.like_count),
    ...(novels || []).map(n => n.like_count),
  ].reduce((a, b) => a + b, 0)

  const stats = [
    { label: 'Total Views', value: formatCount(totalViews), icon: Eye, color: 'text-blue-400' },
    { label: 'Total Likes', value: formatCount(totalLikes), icon: Heart, color: 'text-red-400' },
    { label: 'Shorts', value: shortCount || 0, icon: Play, color: 'text-purple-400' },
    { label: 'Novels', value: novelCount || 0, icon: BookOpen, color: 'text-parchment-400' },
    { label: 'Earnings', value: formatCurrency(user.total_earnings), icon: DollarSign, color: 'text-green-400' },
  ]

  return (
    <main className="min-h-screen pt-20 pb-16">
      <div className="max-w-6xl mx-auto px-4">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="font-display text-3xl font-bold text-cream">Creator Studio</h1>
            <p className="text-cream/50 mt-1">Welcome back, {user.display_name || user.username}</p>
          </div>
          <div className="flex gap-3">
            <Link href="/dashboard/creator/shorts/new" className="btn-ghost text-sm flex items-center gap-2">
              <Play size={15} /> New Short
            </Link>
            <Link href="/dashboard/creator/novels/new" className="btn-primary text-sm flex items-center gap-2">
              <PlusCircle size={15} /> New Novel
            </Link>
          </div>
        </div>

        {/* Stats grid */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-10">
          {stats.map(({ label, value, icon: Icon, color }) => (
            <div key={label} className="glass rounded-2xl p-4">
              <Icon size={20} className={`${color} mb-3`} />
              <p className="text-cream text-xl font-bold">{value}</p>
              <p className="text-cream/40 text-xs mt-1">{label}</p>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Recent Shorts */}
          <section>
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-display text-xl font-semibold text-cream">Recent Shorts</h2>
              <Link href="/dashboard/creator/shorts" className="text-parchment-400 text-sm hover:text-parchment-300">View all</Link>
            </div>
            <div className="space-y-2">
              {shorts?.map(short => (
                <div key={short.id} className="glass rounded-xl px-4 py-3 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Play size={14} className="text-parchment-500" />
                    <span className="text-cream text-sm line-clamp-1">{short.title}</span>
                    {!short.is_published && (
                      <span className="text-xs bg-yellow-900/30 text-yellow-400 px-2 py-0.5 rounded">Draft</span>
                    )}
                  </div>
                  <div className="flex items-center gap-3 text-cream/40 text-xs flex-shrink-0 ml-2">
                    <span className="flex items-center gap-1"><Eye size={11} />{formatCount(short.view_count)}</span>
                    <span className="flex items-center gap-1"><Heart size={11} />{formatCount(short.like_count)}</span>
                    <Link href={`/dashboard/creator/shorts/${short.id}/edit`} className="text-parchment-500 hover:text-parchment-300 transition-colors">Edit</Link>
                  </div>
                </div>
              ))}
              {!shorts?.length && <p className="text-cream/30 text-sm text-center py-6">No shorts yet</p>}
            </div>
          </section>

          {/* Recent Novels */}
          <section>
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-display text-xl font-semibold text-cream">Recent Novels</h2>
              <Link href="/dashboard/creator/novels" className="text-parchment-400 text-sm hover:text-parchment-300">View all</Link>
            </div>
            <div className="space-y-2">
              {novels?.map(novel => (
                <div key={novel.id} className="glass rounded-xl px-4 py-3 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <BookOpen size={14} className="text-parchment-500" />
                    <div>
                      <span className="text-cream text-sm line-clamp-1">{novel.title}</span>
                      <span className="text-cream/40 text-xs ml-1">{novel.total_chapters} ch.</span>
                    </div>
                    {!novel.is_published && (
                      <span className="text-xs bg-yellow-900/30 text-yellow-400 px-2 py-0.5 rounded">Draft</span>
                    )}
                  </div>
                  <div className="flex items-center gap-3 text-cream/40 text-xs flex-shrink-0 ml-2">
                    <span className="flex items-center gap-1"><Eye size={11} />{formatCount(novel.view_count)}</span>
                    <Link href={`/dashboard/creator/novels/${novel.id}`} className="text-parchment-500 hover:text-parchment-300 transition-colors">Edit</Link>
                  </div>
                </div>
              ))}
              {!novels?.length && <p className="text-cream/30 text-sm text-center py-6">No novels yet</p>}
            </div>
          </section>
        </div>
      </div>
    </main>
  )
}
