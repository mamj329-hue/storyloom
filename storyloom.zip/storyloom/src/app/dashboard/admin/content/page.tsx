// src/app/dashboard/admin/content/page.tsx
import { currentUser } from '@clerk/nextjs/server'
import { redirect } from 'next/navigation'
import { createAdminClient } from '@/lib/supabase/server'
import AdminContentTable from '@/components/admin/AdminContentTable'

export default async function AdminContentPage() {
  const clerkUser = await currentUser()
  if (!clerkUser) redirect('/auth/sign-in')

  const supabase = createAdminClient()
  const { data: user } = await supabase.from('users').select('is_admin').eq('clerk_id', clerkUser.id).single()
  if (!user?.is_admin) redirect('/')

  const [{ data: novels }, { data: shorts }] = await Promise.all([
    supabase
      .from('novels')
      .select('id,title,genre,is_published,is_premium,view_count,created_at,creator:users(display_name,email)')
      .order('created_at', { ascending: false })
      .limit(50),
    supabase
      .from('shorts')
      .select('id,title,genre,is_published,is_premium,view_count,created_at,creator:users(display_name,email)')
      .order('created_at', { ascending: false })
      .limit(50),
  ])

  return (
    <main className="min-h-screen pt-20 pb-16">
      <div className="max-w-7xl mx-auto px-4">
        <h1 className="font-display text-3xl font-bold text-cream mb-8">Content Management</h1>
        <AdminContentTable novels={novels || []} shorts={shorts || []} />
      </div>
    </main>
  )
}
