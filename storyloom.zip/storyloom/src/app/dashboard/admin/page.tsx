// src/app/dashboard/admin/page.tsx
import { currentUser } from '@clerk/nextjs/server'
import { redirect } from 'next/navigation'
import { createAdminClient } from '@/lib/supabase/server'
import { formatCurrency, formatCount } from '@/lib/utils'
import Link from 'next/link'
import { Users, BookOpen, Play, DollarSign, TrendingUp, ShieldCheck } from 'lucide-react'

export default async function AdminDashboard() {
  const clerkUser = await currentUser()
  if (!clerkUser) redirect('/auth/sign-in')

  const supabase = createAdminClient()
  const { data: user } = await supabase.from('users').select('is_admin').eq('clerk_id', clerkUser.id).single()
  if (!user?.is_admin) redirect('/')

  const [
    { count: userCount },
    { count: novelCount },
    { count: shortCount },
    { data: recentPayments },
    { data: recentUsers },
  ] = await Promise.all([
    supabase.from('users').select('*', { count: 'exact', head: true }),
    supabase.from('novels').select('*', { count: 'exact', head: true }),
    supabase.from('shorts').select('*', { count: 'exact', head: true }),
    supabase.from('payments').select('amount,status,created_at,user:users(email,display_name)')
      .eq('status', 'success').order('created_at', { ascending: false }).limit(10),
    supabase.from('users').select('id,email,display_name,subscription_status,is_creator,created_at')
      .order('created_at', { ascending: false }).limit(10),
  ])

  const totalRevenue = recentPayments?.reduce((sum, p) => sum + (p.amount || 0), 0) || 0

  const stats = [
    { label: 'Total Users', value: formatCount(userCount || 0), icon: Users, color: 'text-blue-400' },
    { label: 'Novels', value: formatCount(novelCount || 0), icon: BookOpen, color: 'text-parchment-400' },
    { label: 'Shorts', value: formatCount(shortCount || 0), icon: Play, color: 'text-purple-400' },
    { label: 'Revenue (recent)', value: formatCurrency(totalRevenue), icon: DollarSign, color: 'text-green-400' },
  ]

  return (
    <main className="min-h-screen pt-20 pb-16">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex items-center gap-3 mb-8">
          <ShieldCheck size={24} className="text-parchment-400" />
          <div>
            <h1 className="font-display text-3xl font-bold text-cream">Admin Dashboard</h1>
            <p className="text-cream/40 text-sm">Platform management</p>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-10">
          {stats.map(({ label, value, icon: Icon, color }) => (
            <div key={label} className="glass rounded-2xl p-5">
              <Icon size={22} className={`${color} mb-3`} />
              <p className="text-cream text-2xl font-bold">{value}</p>
              <p className="text-cream/40 text-sm mt-1">{label}</p>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Recent Users */}
          <section>
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-display text-xl font-semibold text-cream">Recent Users</h2>
              <Link href="/dashboard/admin/users" className="text-parchment-400 text-sm hover:text-parchment-300">Manage all</Link>
            </div>
            <div className="space-y-2">
              {recentUsers?.map(u => (
                <div key={u.id} className="glass rounded-xl px-4 py-3 flex items-center justify-between">
                  <div>
                    <p className="text-cream text-sm">{u.display_name || u.email}</p>
                    <p className="text-cream/40 text-xs">{u.email}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    {u.is_creator && <span className="text-xs bg-parchment-900/40 text-parchment-400 px-2 py-0.5 rounded">Creator</span>}
                    <span className={`text-xs px-2 py-0.5 rounded ${
                      u.subscription_status === 'premium' ? 'bg-yellow-900/30 text-yellow-400' :
                      u.subscription_status === 'basic' ? 'bg-blue-900/30 text-blue-400' :
                      'bg-ink-800 text-cream/40'
                    }`}>{u.subscription_status}</span>
                  </div>
                </div>
              ))}
            </div>
          </section>

          {/* Recent Payments */}
          <section>
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-display text-xl font-semibold text-cream">Recent Payments</h2>
              <Link href="/dashboard/admin/payments" className="text-parchment-400 text-sm hover:text-parchment-300">View all</Link>
            </div>
            <div className="space-y-2">
              {recentPayments?.map((p, i) => (
                <div key={i} className="glass rounded-xl px-4 py-3 flex items-center justify-between">
                  <div>
                    <p className="text-cream text-sm">{(p.user as any)?.display_name || (p.user as any)?.email}</p>
                    <p className="text-cream/40 text-xs">{new Date(p.created_at).toLocaleDateString()}</p>
                  </div>
                  <span className="text-green-400 font-semibold text-sm">{formatCurrency(p.amount)}</span>
                </div>
              ))}
              {!recentPayments?.length && <p className="text-cream/30 text-sm text-center py-6">No payments yet</p>}
            </div>
          </section>
        </div>

        {/* Quick links */}
        <div className="mt-10 grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            { label: 'Manage Users', href: '/dashboard/admin/users', icon: Users },
            { label: 'Manage Content', href: '/dashboard/admin/content', icon: BookOpen },
            { label: 'View Payments', href: '/dashboard/admin/payments', icon: DollarSign },
            { label: 'Analytics', href: '/dashboard/admin/analytics', icon: TrendingUp },
          ].map(({ label, href, icon: Icon }) => (
            <Link key={href} href={href} className="glass rounded-2xl p-5 hover:border-parchment-700/40 transition-all group flex items-center gap-3">
              <Icon size={18} className="text-parchment-500" />
              <span className="text-cream/70 group-hover:text-cream text-sm transition-colors">{label}</span>
            </Link>
          ))}
        </div>
      </div>
    </main>
  )
}
