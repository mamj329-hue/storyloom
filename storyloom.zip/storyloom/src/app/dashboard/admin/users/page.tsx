// src/app/dashboard/admin/users/page.tsx
import { currentUser } from '@clerk/nextjs/server'
import { redirect } from 'next/navigation'
import { createAdminClient } from '@/lib/supabase/server'
import AdminUsersTable from '@/components/admin/AdminUsersTable'

export default async function AdminUsersPage() {
  const clerkUser = await currentUser()
  if (!clerkUser) redirect('/auth/sign-in')

  const supabase = createAdminClient()
  const { data: me } = await supabase.from('users').select('is_admin').eq('clerk_id', clerkUser.id).single()
  if (!me?.is_admin) redirect('/')

  const { data: users } = await supabase
    .from('users')
    .select('id,clerk_id,email,display_name,username,is_creator,is_admin,subscription_status,subscription_expires_at,total_earnings,created_at')
    .order('created_at', { ascending: false })
    .limit(100)

  return (
    <main className="min-h-screen pt-20 pb-16">
      <div className="max-w-7xl mx-auto px-4">
        <h1 className="font-display text-3xl font-bold text-cream mb-8">User Management</h1>
        <AdminUsersTable users={users || []} />
      </div>
    </main>
  )
}
