// src/app/novels/page.tsx
import type { Metadata } from 'next'
import Link from 'next/link'
import Image from 'next/image'
import { createClient } from '@/lib/supabase/server'
import { GENRES } from '@/types'
import { formatCount } from '@/lib/utils'
import { Star, BookOpen, TrendingUp } from 'lucide-react'

export const metadata: Metadata = {
  title: 'Novels',
  description: 'Discover serialized fiction — romance, thriller, fantasy and more.',
}

export default async function NovelsPage({
  searchParams,
}: {
  searchParams: { genre?: string; sort?: string }
}) {
  const supabase = createClient()
  const genre = searchParams.genre
  const sort = searchParams.sort || 'latest'

  let query = supabase
    .from('novels')
    .select('*, creator:users(id,display_name,username,avatar_url)')
    .eq('is_published', true)

  if (genre) query = query.eq('genre', genre)

  if (sort === 'popular') query = query.order('view_count', { ascending: false })
  else if (sort === 'rating') query = query.order('rating', { ascending: false })
  else query = query.order('created_at', { ascending: false })

  const { data: novels } = await query.limit(40)

  return (
    <main className="min-h-screen pt-20 pb-16">
      <div className="max-w-7xl mx-auto px-4">
        {/* Header */}
        <div className="mb-10">
          <h1 className="font-display text-4xl md:text-5xl font-bold gradient-text mb-3">Novels</h1>
          <p className="text-cream/50 text-lg">Serialized fiction that keeps you coming back</p>
        </div>

        {/* Sort + Genre filters */}
        <div className="flex flex-col sm:flex-row gap-4 mb-8">
          {/* Sort */}
          <div className="flex gap-2">
            {[
              { id: 'latest', label: 'Latest', icon: BookOpen },
              { id: 'popular', label: 'Popular', icon: TrendingUp },
              { id: 'rating', label: 'Top Rated', icon: Star },
            ].map(({ id, label, icon: Icon }) => (
              <Link
                key={id}
                href={`/novels?sort=${id}${genre ? `&genre=${genre}` : ''}`}
                className={`flex items-center gap-1.5 px-4 py-2 rounded-full text-sm font-medium transition-all ${
                  sort === id
                    ? 'bg-parchment-500 text-obsidian'
                    : 'bg-ink-900 text-cream/60 hover:text-cream border border-ink-700'
                }`}
              >
                <Icon size={14} /> {label}
              </Link>
            ))}
          </div>
        </div>

        {/* Genre pills */}
        <div className="flex flex-wrap gap-2 mb-10">
          <Link
            href={`/novels?sort=${sort}`}
            className={`px-3 py-1.5 rounded-full text-xs font-medium transition-all ${
              !genre ? 'bg-parchment-500/20 text-parchment-300 border border-parchment-600/40' : 'bg-ink-900 text-cream/50 border border-ink-800 hover:border-ink-600'
            }`}
          >
            All
          </Link>
          {GENRES.map((g) => (
            <Link
              key={g}
              href={`/novels?sort=${sort}&genre=${g}`}
              className={`px-3 py-1.5 rounded-full text-xs font-medium transition-all ${
                genre === g ? 'bg-parchment-500/20 text-parchment-300 border border-parchment-600/40' : 'bg-ink-900 text-cream/50 border border-ink-800 hover:border-ink-600'
              }`}
            >
              {g}
            </Link>
          ))}
        </div>

        {/* Novels grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
          {novels?.map((novel) => (
            <Link key={novel.id} href={`/novels/${novel.slug}`} className="group">
              <div className="card-novel">
                {/* Cover */}
                <div className="relative aspect-[2/3] bg-ink-900">
                  {novel.cover_url ? (
                    <Image src={novel.cover_url} alt={novel.title} fill className="object-cover" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-parchment-900 to-ink-900">
                      <BookOpen size={32} className="text-parchment-600" />
                    </div>
                  )}
                  {novel.is_premium && (
                    <span className="absolute top-2 right-2 bg-parchment-500 text-obsidian text-xs font-bold px-1.5 py-0.5 rounded">
                      PRO
                    </span>
                  )}
                  {novel.status === 'completed' && (
                    <span className="absolute bottom-2 left-2 bg-ink-950/80 text-green-400 text-xs px-1.5 py-0.5 rounded">
                      Complete
                    </span>
                  )}
                </div>
                {/* Info */}
                <div className="p-2.5">
                  <h3 className="text-cream text-xs font-semibold line-clamp-2 mb-1 group-hover:text-parchment-300 transition-colors">
                    {novel.title}
                  </h3>
                  <div className="flex items-center justify-between">
                    <span className="text-cream/40 text-xs">{novel.total_chapters} ch.</span>
                    <div className="flex items-center gap-1">
                      <Star size={10} className="text-parchment-400 fill-parchment-400" />
                      <span className="text-cream/50 text-xs">{novel.rating.toFixed(1)}</span>
                    </div>
                  </div>
                </div>
              </div>
            </Link>
          ))}
        </div>

        {!novels?.length && (
          <div className="text-center py-24 text-cream/40">
            <BookOpen size={48} className="mx-auto mb-4 opacity-30" />
            <p className="text-lg">No novels found</p>
          </div>
        )}
      </div>
    </main>
  )
}
