// src/app/novels/[slug]/chapter/[number]/page.tsx
import type { Metadata } from 'next'
import { notFound } from 'next/navigation'
import Link from 'next/link'
import { currentUser } from '@clerk/nextjs/server'
import { createClient, createAdminClient } from '@/lib/supabase/server'
import { ChevronLeft, ChevronRight, Lock } from 'lucide-react'
import { formatReadTime } from '@/lib/utils'

interface Props { params: { slug: string; number: string } }

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const supabase = createClient()
  const { data: novel } = await supabase.from('novels').select('title').eq('slug', params.slug).single()
  return { title: `Chapter ${params.number} — ${novel?.title || ''}` }
}

export default async function ChapterPage({ params }: Props) {
  const supabase = createClient()
  const adminSupabase = createAdminClient()
  const clerkUser = await currentUser()

  const { data: novel } = await supabase
    .from('novels').select('id,title,slug,creator_id').eq('slug', params.slug).single()
  if (!novel) notFound()

  const chapterNum = parseInt(params.number)
  const { data: chapter } = await supabase
    .from('chapters')
    .select('*')
    .eq('novel_id', novel.id)
    .eq('chapter_number', chapterNum)
    .eq('is_published', true)
    .single()
  if (!chapter) notFound()

  // Check premium access
  let hasAccess = !chapter.is_premium
  if (chapter.is_premium && clerkUser) {
    const { data: user } = await adminSupabase
      .from('users').select('id,subscription_status,subscription_expires_at').eq('clerk_id', clerkUser.id).single()
    if (user) {
      hasAccess = user.subscription_status !== 'free' &&
        (!user.subscription_expires_at || new Date(user.subscription_expires_at) > new Date())
    }
  }

  // Prev/next chapters
  const { data: adjacent } = await supabase
    .from('chapters')
    .select('chapter_number,title,is_premium')
    .eq('novel_id', novel.id)
    .eq('is_published', true)
    .in('chapter_number', [chapterNum - 1, chapterNum + 1])

  const prev = adjacent?.find(c => c.chapter_number === chapterNum - 1)
  const next = adjacent?.find(c => c.chapter_number === chapterNum + 1)

  // Track view (fire and forget)
  if (hasAccess) {
    adminSupabase.from('chapters').update({ view_count: chapter.view_count + 1 })
      .eq('id', chapter.id).then(() => {})
  }

  return (
    <main className="min-h-screen pt-20 pb-16 bg-obsidian">
      <div className="max-w-2xl mx-auto px-4">
        {/* Breadcrumb */}
        <nav className="flex items-center gap-2 text-sm text-cream/40 mb-8">
          <Link href="/novels" className="hover:text-cream/70 transition-colors">Novels</Link>
          <span>/</span>
          <Link href={`/novels/${novel.slug}`} className="hover:text-cream/70 transition-colors line-clamp-1">
            {novel.title}
          </Link>
          <span>/</span>
          <span className="text-cream/60">Ch. {chapterNum}</span>
        </nav>

        {/* Chapter header */}
        <div className="mb-8 text-center">
          <p className="text-parchment-500 text-sm font-mono mb-2">Chapter {chapterNum}</p>
          <h1 className="font-display text-2xl md:text-3xl font-bold text-cream mb-2">{chapter.title}</h1>
          <p className="text-cream/40 text-sm">{formatReadTime(chapter.word_count)}</p>
        </div>

        {/* Chapter content or lock */}
        {hasAccess ? (
          <article className="prose-story mb-12" dangerouslySetInnerHTML={{ __html: chapter.content.replace(/\n/g, '<br />') }} />
        ) : (
          <div className="relative overflow-hidden rounded-2xl border border-parchment-700/30">
            {/* Blurred preview */}
            <div className="select-none pointer-events-none">
              <p className="text-cream/30 blur-sm leading-relaxed text-lg px-6 pt-6 line-clamp-6">
                {chapter.content.slice(0, 400)}...
              </p>
            </div>
            {/* Lock overlay */}
            <div className="absolute inset-0 bg-gradient-to-t from-obsidian via-obsidian/80 to-transparent flex items-end justify-center pb-10">
              <div className="text-center px-6">
                <div className="w-16 h-16 bg-parchment-500/20 border border-parchment-500/40 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Lock size={28} className="text-parchment-400" />
                </div>
                <h3 className="font-display text-xl font-bold text-cream mb-2">Premium Chapter</h3>
                <p className="text-cream/60 text-sm mb-6">Subscribe to unlock this and all premium chapters</p>
                <div className="flex flex-col sm:flex-row gap-3 justify-center">
                  <Link href="/pricing" className="btn-primary">Unlock with Premium</Link>
                  {!clerkUser && (
                    <Link href="/auth/sign-up" className="btn-ghost">Create Free Account</Link>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Navigation */}
        {hasAccess && (
          <div className="flex items-center justify-between pt-8 border-t border-ink-800/40">
            {prev ? (
              <Link
                href={`/novels/${novel.slug}/chapter/${prev.chapter_number}`}
                className="flex items-center gap-2 text-cream/60 hover:text-parchment-300 transition-colors group"
              >
                <ChevronLeft size={18} className="group-hover:-translate-x-1 transition-transform" />
                <div>
                  <p className="text-xs text-cream/40">Previous</p>
                  <p className="text-sm line-clamp-1">{prev.title}</p>
                </div>
              </Link>
            ) : <div />}

            {next ? (
              <Link
                href={`/novels/${novel.slug}/chapter/${next.chapter_number}`}
                className="flex items-center gap-2 text-cream/60 hover:text-parchment-300 transition-colors text-right group"
              >
                <div>
                  <p className="text-xs text-cream/40">Next</p>
                  <p className="text-sm line-clamp-1">{next.title}</p>
                </div>
                <ChevronRight size={18} className="group-hover:translate-x-1 transition-transform" />
              </Link>
            ) : <div />}
          </div>
        )}
      </div>
    </main>
  )
}
