// src/app/novels/[slug]/page.tsx
import type { Metadata } from 'next'
import Image from 'next/image'
import Link from 'next/link'
import { notFound } from 'next/navigation'
import { createClient } from '@/lib/supabase/server'
import { formatCount, formatDate } from '@/lib/utils'
import { BookOpen, Star, Eye, Heart, Lock, CheckCircle } from 'lucide-react'

interface Props { params: { slug: string } }

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const supabase = createClient()
  const { data: novel } = await supabase
    .from('novels').select('title,synopsis').eq('slug', params.slug).single()
  if (!novel) return { title: 'Not Found' }
  return { title: novel.title, description: novel.synopsis || undefined }
}

export default async function NovelPage({ params }: Props) {
  const supabase = createClient()

  const { data: novel } = await supabase
    .from('novels')
    .select('*, creator:users(id,display_name,username,avatar_url)')
    .eq('slug', params.slug)
    .eq('is_published', true)
    .single()

  if (!novel) notFound()

  const { data: chapters } = await supabase
    .from('chapters')
    .select('id,chapter_number,title,word_count,is_premium,view_count,created_at')
    .eq('novel_id', novel.id)
    .eq('is_published', true)
    .order('chapter_number', { ascending: true })

  return (
    <main className="min-h-screen pt-20 pb-16">
      <div className="max-w-5xl mx-auto px-4">
        {/* Hero */}
        <div className="flex flex-col md:flex-row gap-8 mb-12">
          <div className="flex-shrink-0">
            <div className="relative w-48 h-72 md:w-56 md:h-80 rounded-2xl overflow-hidden shadow-2xl shadow-ink-950/80 mx-auto md:mx-0">
              {novel.cover_url ? (
                <Image src={novel.cover_url} alt={novel.title} fill className="object-cover" />
              ) : (
                <div className="w-full h-full bg-gradient-to-br from-parchment-900 to-ink-900 flex items-center justify-center">
                  <BookOpen size={40} className="text-parchment-600" />
                </div>
              )}
            </div>
          </div>

          <div className="flex-1 text-center md:text-left">
            <div className="flex items-center justify-center md:justify-start gap-2 mb-2">
              <span className="text-xs bg-parchment-500/20 text-parchment-400 px-2 py-0.5 rounded-full border border-parchment-600/30">
                {novel.genre}
              </span>
              <span className={`text-xs px-2 py-0.5 rounded-full ${
                novel.status === 'completed' ? 'bg-green-900/30 text-green-400' :
                novel.status === 'hiatus' ? 'bg-yellow-900/30 text-yellow-400' :
                'bg-blue-900/30 text-blue-400'
              }`}>
                {novel.status.charAt(0).toUpperCase() + novel.status.slice(1)}
              </span>
            </div>

            <h1 className="font-display text-3xl md:text-4xl font-bold text-cream mb-3">{novel.title}</h1>

            <Link href={`/creator/${novel.creator?.username}`} className="flex items-center justify-center md:justify-start gap-2 mb-4 group">
              {novel.creator?.avatar_url && (
                <Image src={novel.creator.avatar_url} alt="" width={24} height={24} className="rounded-full" />
              )}
              <span className="text-parchment-400 text-sm group-hover:text-parchment-300 transition-colors">
                {novel.creator?.display_name || novel.creator?.username}
              </span>
            </Link>

            <div className="flex items-center justify-center md:justify-start gap-5 mb-5 text-cream/60 text-sm">
              <span className="flex items-center gap-1.5"><Eye size={14} />{formatCount(novel.view_count)}</span>
              <span className="flex items-center gap-1.5"><Heart size={14} />{formatCount(novel.like_count)}</span>
              <span className="flex items-center gap-1.5">
                <Star size={14} className="text-parchment-400 fill-parchment-400" />
                {novel.rating.toFixed(1)} ({novel.rating_count})
              </span>
              <span className="flex items-center gap-1.5"><BookOpen size={14} />{novel.total_chapters} chapters</span>
            </div>

            {novel.synopsis && (
              <p className="text-cream/70 leading-relaxed text-sm md:text-base max-w-xl mb-6">{novel.synopsis}</p>
            )}

            <div className="flex flex-col sm:flex-row gap-3 justify-center md:justify-start">
              {chapters && chapters.length > 0 && (
                <Link
                  href={`/novels/${novel.slug}/chapter/${chapters[0].chapter_number}`}
                  className="btn-primary text-center"
                >
                  Start Reading
                </Link>
              )}
              <button className="btn-ghost">Add to Library</button>
            </div>
          </div>
        </div>

        {/* Chapter List */}
        <div>
          <h2 className="font-display text-2xl font-bold text-cream mb-4">Chapters</h2>
          <div className="space-y-1">
            {chapters?.map((ch) => (
              <Link
                key={ch.id}
                href={`/novels/${novel.slug}/chapter/${ch.chapter_number}`}
                className="flex items-center justify-between px-4 py-3.5 rounded-xl bg-ink-950/60 border border-ink-800/40 hover:border-parchment-700/40 hover:bg-ink-900/60 transition-all group"
              >
                <div className="flex items-center gap-3">
                  <span className="text-parchment-500/50 text-xs font-mono w-8 text-right">{ch.chapter_number}</span>
                  <div>
                    <span className="text-cream text-sm group-hover:text-parchment-300 transition-colors">
                      {ch.title}
                    </span>
                    <span className="text-cream/30 text-xs ml-2">{Math.ceil(ch.word_count / 250)} min</span>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-cream/30 text-xs hidden sm:block">{formatDate(ch.created_at)}</span>
                  {ch.is_premium
                    ? <Lock size={14} className="text-parchment-500 flex-shrink-0" />
                    : <CheckCircle size={14} className="text-green-500/60 flex-shrink-0" />
                  }
                </div>
              </Link>
            ))}
          </div>
        </div>
      </div>
    </main>
  )
}
