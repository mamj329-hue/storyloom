// src/app/layout.tsx
import type { Metadata } from 'next'
import { ClerkProvider } from '@clerk/nextjs'
import { Playfair_Display, DM_Sans, DM_Mono } from 'next/font/google'
import { Toaster } from 'react-hot-toast'
import './globals.css'

const playfair = Playfair_Display({
  subsets: ['latin'],
  variable: '--font-playfair',
  display: 'swap',
})

const dmSans = DM_Sans({
  subsets: ['latin'],
  variable: '--font-dm-sans',
  display: 'swap',
})

const dmMono = DM_Mono({
  subsets: ['latin'],
  variable: '--font-dm-mono',
  weight: ['400', '500'],
  display: 'swap',
})

export const metadata: Metadata = {
  title: { default: 'StoryLoom', template: '%s | StoryLoom' },
  description: 'Discover serialized fiction and short story videos. Read, watch, and get lost in stories.',
  keywords: ['fiction', 'novels', 'short videos', 'stories', 'romance', 'thriller', 'reading app'],
  openGraph: {
    type: 'website',
    locale: 'en_NG',
    url: process.env.NEXT_PUBLIC_APP_URL,
    siteName: 'StoryLoom',
  },
  twitter: { card: 'summary_large_image' },
  robots: { index: true, follow: true },
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <ClerkProvider>
      <html lang="en" className={`${playfair.variable} ${dmSans.variable} ${dmMono.variable}`}>
        <body className="bg-obsidian text-cream font-body antialiased">
          {children}
          <Toaster
            position="bottom-center"
            toastOptions={{
              style: {
                background: '#252018',
                color: '#fdfbf7',
                border: '1px solid #3d3020',
                fontFamily: 'var(--font-dm-sans)',
                fontSize: '14px',
              },
            }}
          />
        </body>
      </html>
    </ClerkProvider>
  )
}
