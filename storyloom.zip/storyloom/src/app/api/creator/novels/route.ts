// src/app/api/creator/novels/route.ts
import { NextRequest, NextResponse } from 'next/server'
import { currentUser } from '@clerk/nextjs/server'
import { createAdminClient } from '@/lib/supabase/server'
import { slugify } from '@/lib/utils'

export async function POST(req: NextRequest) {
  const clerkUser = await currentUser()
  if (!clerkUser) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const supabase = createAdminClient()
  const { data: user } = await supabase
    .from('users').select('id,is_creator').eq('clerk_id', clerkUser.id).single()
  if (!user?.is_creator) return NextResponse.json({ error: 'Creator account required' }, { status: 403 })

  const body = await req.json()
  const baseSlug = slugify(body.title)

  // Ensure unique slug
  let slug = baseSlug
  let suffix = 1
  while (true) {
    const { data: existing } = await supabase.from('novels').select('id').eq('slug', slug).single()
    if (!existing) break
    slug = `${baseSlug}-${suffix++}`
  }

  const { data, error } = await supabase.from('novels').insert({
    creator_id: user.id,
    title: body.title,
    slug,
    synopsis: body.synopsis || null,
    cover_url: body.cover_url || null,
    cloudinary_public_id: body.cloudinary_public_id || null,
    genre: body.genre,
    tags: body.tags || [],
    status: body.status || 'ongoing',
    is_premium: body.is_premium || false,
    is_published: body.is_published || false,
  }).select().single()

  if (error) return NextResponse.json({ error: error.message }, { status: 500 })
  return NextResponse.json({ novel: data }, { status: 201 })
}

export async function GET(req: NextRequest) {
  const clerkUser = await currentUser()
  if (!clerkUser) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const supabase = createAdminClient()
  const { data: user } = await supabase.from('users').select('id').eq('clerk_id', clerkUser.id).single()
  if (!user) return NextResponse.json({ error: 'User not found' }, { status: 404 })

  const { data: novels } = await supabase
    .from('novels')
    .select('*')
    .eq('creator_id', user.id)
    .order('created_at', { ascending: false })

  return NextResponse.json({ novels })
}
