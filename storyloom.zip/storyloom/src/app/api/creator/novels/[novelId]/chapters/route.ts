// src/app/api/creator/novels/[novelId]/chapters/route.ts
import { NextRequest, NextResponse } from 'next/server'
import { currentUser } from '@clerk/nextjs/server'
import { createAdminClient } from '@/lib/supabase/server'

export async function GET(req: NextRequest, { params }: { params: { novelId: string } }) {
  const clerkUser = await currentUser()
  if (!clerkUser) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const supabase = createAdminClient()
  const { data: user } = await supabase.from('users').select('id').eq('clerk_id', clerkUser.id).single()
  if (!user) return NextResponse.json({ error: 'User not found' }, { status: 404 })

  // Verify ownership
  const { data: novel } = await supabase
    .from('novels').select('id').eq('id', params.novelId).eq('creator_id', user.id).single()
  if (!novel) return NextResponse.json({ error: 'Novel not found' }, { status: 404 })

  const { data: chapters } = await supabase
    .from('chapters')
    .select('id,chapter_number,title,word_count,is_premium,is_published,view_count,created_at')
    .eq('novel_id', params.novelId)
    .order('chapter_number', { ascending: true })

  return NextResponse.json({ chapters })
}

export async function POST(req: NextRequest, { params }: { params: { novelId: string } }) {
  const clerkUser = await currentUser()
  if (!clerkUser) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const supabase = createAdminClient()
  const { data: user } = await supabase.from('users').select('id,is_creator').eq('clerk_id', clerkUser.id).single()
  if (!user?.is_creator) return NextResponse.json({ error: 'Creator account required' }, { status: 403 })

  const { data: novel } = await supabase
    .from('novels').select('id').eq('id', params.novelId).eq('creator_id', user.id).single()
  if (!novel) return NextResponse.json({ error: 'Novel not found' }, { status: 404 })

  const body = await req.json()

  // Get next chapter number if not provided
  let chapterNumber = body.chapter_number
  if (!chapterNumber) {
    const { data: last } = await supabase
      .from('chapters')
      .select('chapter_number')
      .eq('novel_id', params.novelId)
      .order('chapter_number', { ascending: false })
      .limit(1)
      .single()
    chapterNumber = (last?.chapter_number || 0) + 1
  }

  const { data, error } = await supabase.from('chapters').insert({
    novel_id: params.novelId,
    chapter_number: chapterNumber,
    title: body.title,
    content: body.content,
    is_premium: body.is_premium || false,
    is_published: body.is_published || false,
  }).select().single()

  if (error) return NextResponse.json({ error: error.message }, { status: 500 })
  return NextResponse.json({ chapter: data }, { status: 201 })
}
