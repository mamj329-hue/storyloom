// src/app/api/creator/novels/[novelId]/chapters/[chapterId]/route.ts
import { NextRequest, NextResponse } from 'next/server'
import { currentUser } from '@clerk/nextjs/server'
import { createAdminClient } from '@/lib/supabase/server'

export async function PATCH(
  req: NextRequest,
  { params }: { params: { novelId: string; chapterId: string } }
) {
  const clerkUser = await currentUser()
  if (!clerkUser) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const supabase = createAdminClient()
  const { data: user } = await supabase.from('users').select('id').eq('clerk_id', clerkUser.id).single()
  if (!user) return NextResponse.json({ error: 'User not found' }, { status: 404 })

  // Verify novel ownership
  const { data: novel } = await supabase
    .from('novels').select('id').eq('id', params.novelId).eq('creator_id', user.id).single()
  if (!novel) return NextResponse.json({ error: 'Novel not found' }, { status: 404 })

  const body = await req.json()
  const allowed = ['title', 'content', 'is_premium', 'is_published', 'chapter_number']
  const updates: Record<string, unknown> = {}
  for (const key of allowed) {
    if (key in body) updates[key] = body[key]
  }

  const { data, error } = await supabase
    .from('chapters')
    .update(updates)
    .eq('id', params.chapterId)
    .eq('novel_id', params.novelId)
    .select()
    .single()

  if (error) return NextResponse.json({ error: error.message }, { status: 500 })
  return NextResponse.json({ chapter: data })
}

export async function DELETE(
  req: NextRequest,
  { params }: { params: { novelId: string; chapterId: string } }
) {
  const clerkUser = await currentUser()
  if (!clerkUser) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const supabase = createAdminClient()
  const { data: user } = await supabase.from('users').select('id').eq('clerk_id', clerkUser.id).single()
  if (!user) return NextResponse.json({ error: 'User not found' }, { status: 404 })

  const { data: novel } = await supabase
    .from('novels').select('id').eq('id', params.novelId).eq('creator_id', user.id).single()
  if (!novel) return NextResponse.json({ error: 'Forbidden' }, { status: 403 })

  const { error } = await supabase
    .from('chapters').delete().eq('id', params.chapterId).eq('novel_id', params.novelId)

  if (error) return NextResponse.json({ error: error.message }, { status: 500 })
  return NextResponse.json({ deleted: true })
}
