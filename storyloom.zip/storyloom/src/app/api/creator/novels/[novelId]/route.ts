// src/app/api/creator/novels/[novelId]/route.ts
import { NextRequest, NextResponse } from 'next/server'
import { currentUser } from '@clerk/nextjs/server'
import { createAdminClient } from '@/lib/supabase/server'

export async function GET(req: NextRequest, { params }: { params: { novelId: string } }) {
  const clerkUser = await currentUser()
  if (!clerkUser) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const supabase = createAdminClient()
  const { data: user } = await supabase.from('users').select('id').eq('clerk_id', clerkUser.id).single()
  if (!user) return NextResponse.json({ error: 'User not found' }, { status: 404 })

  const { data: novel, error } = await supabase
    .from('novels')
    .select('*')
    .eq('id', params.novelId)
    .eq('creator_id', user.id)
    .single()

  if (error || !novel) return NextResponse.json({ error: 'Novel not found' }, { status: 404 })
  return NextResponse.json({ novel })
}

export async function PATCH(req: NextRequest, { params }: { params: { novelId: string } }) {
  const clerkUser = await currentUser()
  if (!clerkUser) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const supabase = createAdminClient()
  const { data: user } = await supabase.from('users').select('id').eq('clerk_id', clerkUser.id).single()
  if (!user) return NextResponse.json({ error: 'User not found' }, { status: 404 })

  const body = await req.json()
  const allowed = ['title', 'synopsis', 'cover_url', 'cloudinary_public_id', 'genre', 'tags', 'status', 'is_premium', 'is_published']
  const updates: Record<string, unknown> = {}
  for (const key of allowed) {
    if (key in body) updates[key] = body[key]
  }

  const { data, error } = await supabase
    .from('novels')
    .update(updates)
    .eq('id', params.novelId)
    .eq('creator_id', user.id)
    .select()
    .single()

  if (error) return NextResponse.json({ error: error.message }, { status: 500 })
  return NextResponse.json({ novel: data })
}

export async function DELETE(req: NextRequest, { params }: { params: { novelId: string } }) {
  const clerkUser = await currentUser()
  if (!clerkUser) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const supabase = createAdminClient()
  const { data: user } = await supabase.from('users').select('id,is_admin').eq('clerk_id', clerkUser.id).single()
  if (!user) return NextResponse.json({ error: 'User not found' }, { status: 404 })

  const { error } = await supabase
    .from('novels')
    .delete()
    .eq('id', params.novelId)
    .eq('creator_id', user.id)

  if (error) return NextResponse.json({ error: error.message }, { status: 500 })
  return NextResponse.json({ deleted: true })
}
