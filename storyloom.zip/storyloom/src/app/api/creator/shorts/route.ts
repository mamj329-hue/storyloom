// src/app/api/creator/shorts/route.ts
import { NextRequest, NextResponse } from 'next/server'
import { currentUser } from '@clerk/nextjs/server'
import { createAdminClient } from '@/lib/supabase/server'

export async function POST(req: NextRequest) {
  const clerkUser = await currentUser()
  if (!clerkUser) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const supabase = createAdminClient()
  const { data: user } = await supabase
    .from('users').select('id,is_creator').eq('clerk_id', clerkUser.id).single()

  if (!user?.is_creator) return NextResponse.json({ error: 'Creator account required' }, { status: 403 })

  const body = await req.json()
  const { data, error } = await supabase.from('shorts').insert({
    creator_id: user.id,
    title: body.title,
    description: body.description || null,
    video_url: body.video_url,
    thumbnail_url: body.thumbnail_url || null,
    cloudinary_public_id: body.cloudinary_public_id || null,
    duration_seconds: body.duration_seconds || null,
    genre: body.genre || null,
    tags: body.tags || [],
    is_premium: body.is_premium || false,
    is_published: body.is_published || false,
  }).select().single()

  if (error) return NextResponse.json({ error: error.message }, { status: 500 })
  return NextResponse.json({ short: data })
}

export async function GET(req: NextRequest) {
  const clerkUser = await currentUser()
  if (!clerkUser) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const supabase = createAdminClient()
  const { data: user } = await supabase.from('users').select('id').eq('clerk_id', clerkUser.id).single()
  if (!user) return NextResponse.json({ error: 'User not found' }, { status: 404 })

  const { data: shorts } = await supabase
    .from('shorts').select('*').eq('creator_id', user.id).order('created_at', { ascending: false })

  return NextResponse.json({ shorts })
}
