// src/app/api/creator/apply/route.ts
import { NextRequest, NextResponse } from 'next/server'
import { currentUser } from '@clerk/nextjs/server'
import { createAdminClient } from '@/lib/supabase/server'

export async function POST(req: NextRequest) {
  const clerkUser = await currentUser()
  if (!clerkUser) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const supabase = createAdminClient()
  const { data: user } = await supabase
    .from('users').select('id,is_creator').eq('clerk_id', clerkUser.id).single()

  if (!user) return NextResponse.json({ error: 'User not found' }, { status: 404 })
  if (user.is_creator) return NextResponse.json({ message: 'Already a creator' })

  const { error } = await supabase
    .from('users').update({ is_creator: true }).eq('id', user.id)

  if (error) return NextResponse.json({ error: error.message }, { status: 500 })
  return NextResponse.json({ success: true })
}
