// src/app/api/search/route.ts
import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'

export async function GET(req: NextRequest) {
  const q = req.nextUrl.searchParams.get('q')?.trim()
  const type = req.nextUrl.searchParams.get('type') || 'all' // all | novels | shorts
  const limit = parseInt(req.nextUrl.searchParams.get('limit') || '10')

  if (!q || q.length < 2) {
    return NextResponse.json({ novels: [], shorts: [] })
  }

  const supabase = createClient()
  const results: { novels: unknown[]; shorts: unknown[] } = { novels: [], shorts: [] }

  if (type === 'all' || type === 'novels') {
    const { data } = await supabase
      .from('novels')
      .select('id,title,slug,cover_url,genre,rating,total_chapters,creator:users(display_name,username)')
      .eq('is_published', true)
      .or(`title.ilike.%${q}%,synopsis.ilike.%${q}%,genre.ilike.%${q}%`)
      .limit(limit)
    results.novels = data || []
  }

  if (type === 'all' || type === 'shorts') {
    const { data } = await supabase
      .from('shorts')
      .select('id,title,thumbnail_url,genre,view_count,creator:users(display_name,username)')
      .eq('is_published', true)
      .or(`title.ilike.%${q}%,description.ilike.%${q}%,genre.ilike.%${q}%`)
      .limit(limit)
    results.shorts = data || []
  }

  return NextResponse.json(results)
}
