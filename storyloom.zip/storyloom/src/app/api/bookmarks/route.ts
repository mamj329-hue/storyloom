// src/app/api/bookmarks/route.ts
import { NextRequest, NextResponse } from 'next/server'
import { currentUser } from '@clerk/nextjs/server'
import { createAdminClient, createClient } from '@/lib/supabase/server'

export async function GET(req: NextRequest) {
  const clerkUser = await currentUser()
  if (!clerkUser) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const content_type = req.nextUrl.searchParams.get('content_type')
  const supabase = createAdminClient()

  const { data: user } = await supabase.from('users').select('id').eq('clerk_id', clerkUser.id).single()
  if (!user) return NextResponse.json({ error: 'User not found' }, { status: 404 })

  let query = supabase.from('bookmarks').select('*').eq('user_id', user.id)
  if (content_type) query = query.eq('content_type', content_type)

  const { data: bookmarks, error } = await query.order('created_at', { ascending: false })
  if (error) return NextResponse.json({ error: error.message }, { status: 500 })
  return NextResponse.json({ bookmarks })
}

export async function POST(req: NextRequest) {
  const clerkUser = await currentUser()
  if (!clerkUser) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { content_type, content_id } = await req.json()
  const supabase = createAdminClient()

  const { data: user } = await supabase.from('users').select('id').eq('clerk_id', clerkUser.id).single()
  if (!user) return NextResponse.json({ error: 'User not found' }, { status: 404 })

  await supabase.from('bookmarks').upsert(
    { user_id: user.id, content_type, content_id },
    { onConflict: 'user_id,content_type,content_id' }
  )
  return NextResponse.json({ bookmarked: true })
}

export async function DELETE(req: NextRequest) {
  const clerkUser = await currentUser()
  if (!clerkUser) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { content_type, content_id } = await req.json()
  const supabase = createAdminClient()

  const { data: user } = await supabase.from('users').select('id').eq('clerk_id', clerkUser.id).single()
  if (!user) return NextResponse.json({ error: 'User not found' }, { status: 404 })

  await supabase.from('bookmarks').delete().match({ user_id: user.id, content_type, content_id })
  return NextResponse.json({ bookmarked: false })
}
