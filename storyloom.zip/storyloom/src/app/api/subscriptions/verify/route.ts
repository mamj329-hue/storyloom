// src/app/api/subscriptions/verify/route.ts
import { NextRequest, NextResponse } from 'next/server'
import { createAdminClient } from '@/lib/supabase/server'
import { verifyTransaction } from '@/lib/paystack'

export async function GET(req: NextRequest) {
  const reference = req.nextUrl.searchParams.get('reference')
  if (!reference) return NextResponse.redirect(new URL('/pricing?error=missing_ref', req.url))

  try {
    const verified = await verifyTransaction(reference)
    if (verified.status !== 'success') {
      return NextResponse.redirect(new URL('/pricing?error=payment_failed', req.url))
    }

    const supabase = createAdminClient()
    await supabase.from('payments')
      .update({ status: 'success', paystack_transaction_id: verified.id?.toString() })
      .eq('paystack_reference', reference)

    const plan = verified.metadata?.plan
    const userId = verified.metadata?.user_id
    if (plan && userId) {
      const periodEnd = new Date()
      periodEnd.setMonth(periodEnd.getMonth() + 1)
      await supabase.from('users').update({
        subscription_status: plan,
        subscription_expires_at: periodEnd.toISOString(),
      }).eq('id', userId)
    }

    return NextResponse.redirect(new URL('/pricing?success=true', req.url))
  } catch (error) {
    console.error('Verify error:', error)
    return NextResponse.redirect(new URL('/pricing?error=verify_failed', req.url))
  }
}
