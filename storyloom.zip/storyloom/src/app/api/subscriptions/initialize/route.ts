// src/app/api/subscriptions/initialize/route.ts
import { NextRequest, NextResponse } from 'next/server'
import { currentUser } from '@clerk/nextjs/server'
import { createAdminClient } from '@/lib/supabase/server'
import { initializeTransaction, generateReference, PAYSTACK_PLANS } from '@/lib/paystack'

export async function POST(req: NextRequest) {
  try {
    const clerkUser = await currentUser()
    if (!clerkUser) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

    const { plan } = await req.json()
    if (!['basic', 'premium'].includes(plan)) {
      return NextResponse.json({ error: 'Invalid plan' }, { status: 400 })
    }

    const supabase = createAdminClient()
    const { data: user } = await supabase
      .from('users')
      .select('id,email,paystack_customer_code')
      .eq('clerk_id', clerkUser.id)
      .single()

    if (!user) return NextResponse.json({ error: 'User not found' }, { status: 404 })

    const planConfig = PAYSTACK_PLANS[plan as keyof typeof PAYSTACK_PLANS]
    const reference = generateReference('SUB')

    // Store pending payment
    await supabase.from('payments').insert({
      user_id: user.id,
      paystack_reference: reference,
      amount: planConfig.amount / 100,
      currency: 'NGN',
      status: 'pending',
      metadata: { plan, type: 'subscription' },
    })

    const transaction = await initializeTransaction({
      email: user.email,
      amount: planConfig.amount,
      reference,
      plan: process.env[`PAYSTACK_${plan.toUpperCase()}_PLAN_CODE`] || '',
      callback_url: `${process.env.NEXT_PUBLIC_APP_URL}/api/subscriptions/verify?reference=${reference}`,
      metadata: { user_id: user.id, plan, clerk_id: clerkUser.id },
    })

    return NextResponse.json(transaction)
  } catch (error) {
    console.error('Subscription init error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}
