// src/app/api/upload/video/route.ts
import { NextRequest, NextResponse } from 'next/server'
import { currentUser } from '@clerk/nextjs/server'
import { createAdminClient } from '@/lib/supabase/server'
import { uploadVideo, getVideoThumbnail } from '@/lib/cloudinary'

export async function POST(req: NextRequest) {
  const clerkUser = await currentUser()
  if (!clerkUser) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const supabase = createAdminClient()
  const { data: user } = await supabase
    .from('users').select('id,is_creator').eq('clerk_id', clerkUser.id).single()

  if (!user?.is_creator) return NextResponse.json({ error: 'Creator account required' }, { status: 403 })

  const formData = await req.formData()
  const file = formData.get('file') as File
  if (!file) return NextResponse.json({ error: 'No file provided' }, { status: 400 })

  const bytes = await file.arrayBuffer()
  const buffer = Buffer.from(bytes)
  const base64 = `data:${file.type};base64,${buffer.toString('base64')}`

  const result = await uploadVideo(base64, `storyloom/shorts/${user.id}`)
  const thumbnail = getVideoThumbnail(result.public_id)

  return NextResponse.json({
    url: result.secure_url,
    public_id: result.public_id,
    thumbnail_url: thumbnail,
    duration: result.duration,
  })
}

export const config = { api: { bodyParser: false } }
