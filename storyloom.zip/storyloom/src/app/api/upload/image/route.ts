// src/app/api/upload/image/route.ts
import { NextRequest, NextResponse } from 'next/server'
import { currentUser } from '@clerk/nextjs/server'
import { createAdminClient } from '@/lib/supabase/server'
import { uploadImage } from '@/lib/cloudinary'

export async function POST(req: NextRequest) {
  const clerkUser = await currentUser()
  if (!clerkUser) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const supabase = createAdminClient()
  const { data: user } = await supabase
    .from('users').select('id,is_creator').eq('clerk_id', clerkUser.id).single()
  if (!user?.is_creator) return NextResponse.json({ error: 'Creator account required' }, { status: 403 })

  const formData = await req.formData()
  const file = formData.get('file') as File
  const folder = (formData.get('folder') as string) || 'storyloom/covers'

  if (!file) return NextResponse.json({ error: 'No file provided' }, { status: 400 })
  if (file.size > 10 * 1024 * 1024) return NextResponse.json({ error: 'File must be under 10MB' }, { status: 400 })

  const bytes = await file.arrayBuffer()
  const base64 = `data:${file.type};base64,${Buffer.from(bytes).toString('base64')}`

  const result = await uploadImage(base64, `${folder}/${user.id}`)

  return NextResponse.json({
    url: result.secure_url,
    public_id: result.public_id,
  })
}
