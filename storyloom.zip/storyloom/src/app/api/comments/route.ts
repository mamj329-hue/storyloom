// src/app/api/comments/route.ts
import { NextRequest, NextResponse } from 'next/server'
import { currentUser } from '@clerk/nextjs/server'
import { createAdminClient, createClient } from '@/lib/supabase/server'

export async function GET(req: NextRequest) {
  const content_type = req.nextUrl.searchParams.get('content_type')
  const content_id = req.nextUrl.searchParams.get('content_id')
  const offset = parseInt(req.nextUrl.searchParams.get('offset') || '0')

  if (!content_type || !content_id) {
    return NextResponse.json({ error: 'Missing params' }, { status: 400 })
  }

  const supabase = createClient()
  const { data: comments, error } = await supabase
    .from('comments')
    .select('*, user:users(id,display_name,username,avatar_url)')
    .eq('content_type', content_type)
    .eq('content_id', content_id)
    .is('parent_id', null)
    .order('is_pinned', { ascending: false })
    .order('created_at', { ascending: false })
    .range(offset, offset + 19)

  if (error) return NextResponse.json({ error: error.message }, { status: 500 })
  return NextResponse.json({ comments })
}

export async function POST(req: NextRequest) {
  const clerkUser = await currentUser()
  if (!clerkUser) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { content_type, content_id, body, parent_id } = await req.json()
  if (!body?.trim()) return NextResponse.json({ error: 'Comment cannot be empty' }, { status: 400 })

  const supabase = createAdminClient()
  const { data: user } = await supabase.from('users').select('id').eq('clerk_id', clerkUser.id).single()
  if (!user) return NextResponse.json({ error: 'User not found' }, { status: 404 })

  const { data: comment, error } = await supabase
    .from('comments')
    .insert({ user_id: user.id, content_type, content_id, body: body.trim(), parent_id: parent_id || null })
    .select('*, user:users(id,display_name,username,avatar_url)')
    .single()

  if (error) return NextResponse.json({ error: error.message }, { status: 500 })

  // Increment comment count on shorts
  if (content_type === 'short') {
    await supabase.rpc('increment_comment_count', { short_id: content_id })
  }

  return NextResponse.json({ comment }, { status: 201 })
}

export async function DELETE(req: NextRequest) {
  const clerkUser = await currentUser()
  if (!clerkUser) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { comment_id } = await req.json()
  const supabase = createAdminClient()

  const { data: user } = await supabase.from('users').select('id,is_admin').eq('clerk_id', clerkUser.id).single()
  if (!user) return NextResponse.json({ error: 'User not found' }, { status: 404 })

  const { data: comment } = await supabase.from('comments').select('user_id').eq('id', comment_id).single()
  if (!comment) return NextResponse.json({ error: 'Comment not found' }, { status: 404 })

  if (comment.user_id !== user.id && !user.is_admin) {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
  }

  await supabase.from('comments').delete().eq('id', comment_id)
  return NextResponse.json({ deleted: true })
}
