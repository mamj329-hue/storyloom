// src/app/api/webhooks/clerk/route.ts
import { NextRequest, NextResponse } from 'next/server'
import { Webhook } from 'svix'
import { createAdminClient } from '@/lib/supabase/server'

export async function POST(req: NextRequest) {
  const WEBHOOK_SECRET = process.env.CLERK_WEBHOOK_SECRET
  if (!WEBHOOK_SECRET) return NextResponse.json({ error: 'No webhook secret' }, { status: 500 })

  const headers = {
    'svix-id': req.headers.get('svix-id') || '',
    'svix-timestamp': req.headers.get('svix-timestamp') || '',
    'svix-signature': req.headers.get('svix-signature') || '',
  }

  const payload = await req.text()
  let event: any

  try {
    const wh = new Webhook(WEBHOOK_SECRET)
    event = wh.verify(payload, headers)
  } catch {
    return NextResponse.json({ error: 'Invalid webhook signature' }, { status: 400 })
  }

  const supabase = createAdminClient()

  switch (event.type) {
    case 'user.created': {
      const { id, email_addresses, first_name, last_name, image_url, username } = event.data
      await supabase.from('users').insert({
        clerk_id: id,
        email: email_addresses[0]?.email_address,
        username: username || null,
        display_name: [first_name, last_name].filter(Boolean).join(' ') || null,
        avatar_url: image_url || null,
      })
      break
    }
    case 'user.updated': {
      const { id, email_addresses, first_name, last_name, image_url, username } = event.data
      await supabase.from('users').update({
        email: email_addresses[0]?.email_address,
        username: username || null,
        display_name: [first_name, last_name].filter(Boolean).join(' ') || null,
        avatar_url: image_url || null,
      }).eq('clerk_id', id)
      break
    }
    case 'user.deleted': {
      await supabase.from('users').delete().eq('clerk_id', event.data.id)
      break
    }
  }

  return NextResponse.json({ received: true })
}
