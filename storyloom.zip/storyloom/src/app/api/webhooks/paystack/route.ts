// src/app/api/webhooks/paystack/route.ts
import { NextRequest, NextResponse } from 'next/server'
import { createAdminClient } from '@/lib/supabase/server'
import { verifyWebhookSignature, verifyTransaction } from '@/lib/paystack'

export async function POST(req: NextRequest) {
  const rawBody = await req.text()
  const signature = req.headers.get('x-paystack-signature') || ''

  if (!verifyWebhookSignature(rawBody, signature)) {
    return NextResponse.json({ error: 'Invalid signature' }, { status: 400 })
  }

  const event = JSON.parse(rawBody)
  const supabase = createAdminClient()

  try {
    switch (event.event) {
      case 'charge.success': {
        const { reference, metadata, customer } = event.data
        const verified = await verifyTransaction(reference)
        if (verified.status !== 'success') break

        const plan = metadata?.plan as 'basic' | 'premium'
        const userId = metadata?.user_id

        if (!plan || !userId) break

        const now = new Date()
        const periodEnd = new Date(now)
        periodEnd.setMonth(periodEnd.getMonth() + 1)

        // Upsert subscription
        await supabase.from('subscriptions').upsert({
          user_id: userId,
          plan,
          status: 'active',
          amount: verified.amount / 100,
          currency: 'NGN',
          current_period_start: now.toISOString(),
          current_period_end: periodEnd.toISOString(),
        }, { onConflict: 'user_id' })

        // Update payment record
        await supabase.from('payments')
          .update({
            status: 'success',
            paystack_transaction_id: verified.id?.toString(),
          })
          .eq('paystack_reference', reference)

        // Update user subscription status
        await supabase.from('users')
          .update({
            subscription_status: plan,
            subscription_expires_at: periodEnd.toISOString(),
            paystack_customer_code: customer?.customer_code,
          })
          .eq('id', userId)

        break
      }

      case 'subscription.disable':
      case 'subscription.not_renew': {
        const { subscription_code } = event.data
        await supabase.from('subscriptions')
          .update({ status: 'cancelled', cancelled_at: new Date().toISOString() })
          .eq('paystack_subscription_code', subscription_code)
        break
      }

      case 'invoice.payment_failed': {
        const { subscription } = event.data
        await supabase.from('subscriptions')
          .update({ status: 'expired' })
          .eq('paystack_subscription_code', subscription?.subscription_code)
        break
      }
    }

    return NextResponse.json({ received: true })
  } catch (error) {
    console.error('Webhook error:', error)
    return NextResponse.json({ error: 'Webhook processing failed' }, { status: 500 })
  }
}
