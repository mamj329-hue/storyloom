// src/app/api/likes/route.ts
import { NextRequest, NextResponse } from 'next/server'
import { currentUser } from '@clerk/nextjs/server'
import { createAdminClient } from '@/lib/supabase/server'

export async function POST(req: NextRequest) {
  const clerkUser = await currentUser()
  if (!clerkUser) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { content_type, content_id } = await req.json()
  const supabase = createAdminClient()

  const { data: user } = await supabase.from('users').select('id').eq('clerk_id', clerkUser.id).single()
  if (!user) return NextResponse.json({ error: 'User not found' }, { status: 404 })

  await supabase.from('likes').upsert({ user_id: user.id, content_type, content_id }, { onConflict: 'user_id,content_type,content_id' })

  const table = content_type === 'short' ? 'shorts' : content_type === 'novel' ? 'novels' : 'chapters'
  await supabase.rpc('increment_like_count', { row_id: content_id, table_name: table })

  return NextResponse.json({ liked: true })
}

export async function DELETE(req: NextRequest) {
  const clerkUser = await currentUser()
  if (!clerkUser) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { content_type, content_id } = await req.json()
  const supabase = createAdminClient()

  const { data: user } = await supabase.from('users').select('id').eq('clerk_id', clerkUser.id).single()
  if (!user) return NextResponse.json({ error: 'User not found' }, { status: 404 })

  await supabase.from('likes').delete().match({ user_id: user.id, content_type, content_id })

  return NextResponse.json({ liked: false })
}
