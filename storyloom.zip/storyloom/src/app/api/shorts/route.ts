// src/app/api/shorts/route.ts
import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'

export async function GET(req: NextRequest) {
  const offset = parseInt(req.nextUrl.searchParams.get('offset') || '0')
  const limit = parseInt(req.nextUrl.searchParams.get('limit') || '10')
  const genre = req.nextUrl.searchParams.get('genre')

  const supabase = createClient()
  let query = supabase
    .from('shorts')
    .select('*, creator:users(id,display_name,username,avatar_url)')
    .eq('is_published', true)
    .order('created_at', { ascending: false })
    .range(offset, offset + limit - 1)

  if (genre) query = query.eq('genre', genre)

  const { data: shorts, error } = await query
  if (error) return NextResponse.json({ error: error.message }, { status: 500 })
  return NextResponse.json({ shorts })
}
