// src/app/api/admin/novels/[novelId]/route.ts
import { NextRequest, NextResponse } from 'next/server'
import { currentUser } from '@clerk/nextjs/server'
import { createAdminClient } from '@/lib/supabase/server'

async function verifyAdmin(clerkId: string) {
  const supabase = createAdminClient()
  const { data } = await supabase.from('users').select('id,is_admin').eq('clerk_id', clerkId).single()
  return data?.is_admin ? data : null
}

export async function PATCH(req: NextRequest, { params }: { params: { novelId: string } }) {
  const clerkUser = await currentUser()
  if (!clerkUser) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  const admin = await verifyAdmin(clerkUser.id)
  if (!admin) return NextResponse.json({ error: 'Forbidden' }, { status: 403 })

  const supabase = createAdminClient()
  const body = await req.json()
  const allowed = ['is_published', 'is_premium', 'genre', 'status']
  const updates: Record<string, unknown> = {}
  for (const key of allowed) if (key in body) updates[key] = body[key]

  const { data, error } = await supabase.from('novels').update(updates).eq('id', params.novelId).select().single()
  if (error) return NextResponse.json({ error: error.message }, { status: 500 })
  return NextResponse.json({ novel: data })
}

export async function DELETE(req: NextRequest, { params }: { params: { novelId: string } }) {
  const clerkUser = await currentUser()
  if (!clerkUser) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  const admin = await verifyAdmin(clerkUser.id)
  if (!admin) return NextResponse.json({ error: 'Forbidden' }, { status: 403 })

  const supabase = createAdminClient()
  const { error } = await supabase.from('novels').delete().eq('id', params.novelId)
  if (error) return NextResponse.json({ error: error.message }, { status: 500 })
  return NextResponse.json({ deleted: true })
}
