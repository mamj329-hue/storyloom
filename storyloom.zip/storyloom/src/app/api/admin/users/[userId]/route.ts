// src/app/api/admin/users/[userId]/route.ts
import { NextRequest, NextResponse } from 'next/server'
import { currentUser } from '@clerk/nextjs/server'
import { createAdminClient } from '@/lib/supabase/server'

async function verifyAdmin(clerkId: string) {
  const supabase = createAdminClient()
  const { data } = await supabase.from('users').select('id,is_admin').eq('clerk_id', clerkId).single()
  return data?.is_admin ? data : null
}

export async function PATCH(req: NextRequest, { params }: { params: { userId: string } }) {
  const clerkUser = await currentUser()
  if (!clerkUser) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  const admin = await verifyAdmin(clerkUser.id)
  if (!admin) return NextResponse.json({ error: 'Forbidden' }, { status: 403 })

  const supabase = createAdminClient()
  const body = await req.json()
  const allowed = ['is_creator', 'is_admin', 'subscription_status']
  const updates: Record<string, unknown> = {}
  for (const key of allowed) if (key in body) updates[key] = body[key]

  const { data, error } = await supabase
    .from('users').update(updates).eq('id', params.userId).select().single()
  if (error) return NextResponse.json({ error: error.message }, { status: 500 })
  return NextResponse.json({ user: data })
}

export async function DELETE(req: NextRequest, { params }: { params: { userId: string } }) {
  const clerkUser = await currentUser()
  if (!clerkUser) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  const admin = await verifyAdmin(clerkUser.id)
  if (!admin) return NextResponse.json({ error: 'Forbidden' }, { status: 403 })

  // Prevent self-deletion
  const supabase = createAdminClient()
  const { data: target } = await supabase.from('users').select('clerk_id').eq('id', params.userId).single()
  if (target?.clerk_id === clerkUser.id) {
    return NextResponse.json({ error: 'Cannot delete your own account' }, { status: 400 })
  }

  const { error } = await supabase.from('users').delete().eq('id', params.userId)
  if (error) return NextResponse.json({ error: error.message }, { status: 500 })
  return NextResponse.json({ deleted: true })
}
