// src/app/auth/sign-up/page.tsx
import { SignUp } from '@clerk/nextjs'
import type { Metadata } from 'next'

export const metadata: Metadata = { title: 'Create Account' }

export default function SignUpPage() {
  return (
    <main className="min-h-screen flex items-center justify-center px-4 pt-20 pb-16">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <span className="font-display text-3xl font-bold gradient-text">StoryLoom</span>
          <p className="text-cream/50 mt-2 text-sm">Create your free account</p>
        </div>
        <SignUp
          appearance={{
            elements: {
              rootBox: 'w-full',
              card: 'bg-ink-950/80 border border-ink-800/50 shadow-2xl shadow-ink-950/80 rounded-2xl',
              headerTitle: 'text-cream font-display',
              headerSubtitle: 'text-cream/50',
              socialButtonsBlockButton: 'bg-ink-900 border border-ink-700 text-cream hover:bg-ink-800 transition-colors',
              dividerLine: 'bg-ink-700',
              dividerText: 'text-cream/30',
              formFieldLabel: 'text-cream/70',
              formFieldInput: 'bg-ink-900 border-ink-700 text-cream focus:border-parchment-600 rounded-xl',
              formButtonPrimary: 'bg-parchment-500 hover:bg-parchment-400 text-obsidian font-semibold rounded-full',
              footerActionLink: 'text-parchment-400 hover:text-parchment-300',
            },
          }}
        />
      </div>
    </main>
  )
}
