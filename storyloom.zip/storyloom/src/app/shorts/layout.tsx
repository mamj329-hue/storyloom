// src/app/shorts/layout.tsx
import type { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'Shorts',
  description: 'Short story videos — scroll, watch, get lost.',
}

export default function ShortsLayout({ children }: { children: React.ReactNode }) {
  // Shorts feed is full-viewport — no navbar chrome
  return <div className="relative w-full">{children}</div>
}
