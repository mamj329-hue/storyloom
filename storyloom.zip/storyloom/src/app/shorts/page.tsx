// src/app/shorts/page.tsx
import type { Metadata } from 'next'
import ShortsFeed from '@/components/shorts/ShortsFeed'
import { createClient } from '@/lib/supabase/server'

export const metadata: Metadata = {
  title: 'Shorts',
  description: 'Watch short story videos from talented creators.',
}

export default async function ShortsPage() {
  const supabase = createClient()
  const { data: shorts } = await supabase
    .from('shorts')
    .select('*, creator:users(id,display_name,username,avatar_url)')
    .eq('is_published', true)
    .order('created_at', { ascending: false })
    .limit(20)

  return <ShortsFeed initialShorts={shorts || []} />
}
