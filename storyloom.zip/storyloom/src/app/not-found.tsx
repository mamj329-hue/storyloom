// src/app/not-found.tsx
import Link from 'next/link'
import { BookOpen } from 'lucide-react'

export default function NotFound() {
  return (
    <main className="min-h-screen flex items-center justify-center px-4 text-center">
      <div>
        <p className="font-mono text-parchment-600 text-sm tracking-widest mb-4">404</p>
        <h1 className="font-display text-4xl md:text-5xl font-bold text-cream mb-4">
          Page not found
        </h1>
        <p className="text-cream/50 text-lg mb-10 max-w-md mx-auto">
          The story you were looking for doesn't exist — or maybe it hasn't been written yet.
        </p>
        <div className="flex flex-col sm:flex-row gap-3 justify-center">
          <Link href="/novels" className="btn-primary flex items-center justify-center gap-2">
            <BookOpen size={16} /> Browse Novels
          </Link>
          <Link href="/" className="btn-ghost">
            Back to Home
          </Link>
        </div>
      </div>
    </main>
  )
}
