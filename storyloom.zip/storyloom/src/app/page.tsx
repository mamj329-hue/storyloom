// src/app/page.tsx
import type { Metadata } from 'next'
import Link from 'next/link'
import Image from 'next/image'
import { createClient } from '@/lib/supabase/server'
import { Play, BookOpen, Sparkles, ArrowRight, Star } from 'lucide-react'
import Navbar from '@/components/shared/Navbar'

export const metadata: Metadata = {
  title: 'StoryLoom — Stories That Move',
  description: 'Watch short story videos and read serialized fiction. Discover romance, thriller, fantasy and more.',
}

export default async function HomePage() {
  const supabase = createClient()

  const [{ data: featuredNovels }, { data: featuredShorts }] = await Promise.all([
    supabase.from('novels').select('id,title,slug,cover_url,genre,rating,total_chapters')
      .eq('is_published', true).order('rating', { ascending: false }).limit(6),
    supabase.from('shorts').select('id,title,thumbnail_url,genre,view_count,creator:users(display_name,username)')
      .eq('is_published', true).order('view_count', { ascending: false }).limit(4),
  ])

  return (
    <>
      <Navbar />
      <main className="overflow-hidden">
        {/* ── HERO ── */}
        <section className="relative min-h-screen flex items-center justify-center px-4 pt-20">
          {/* Background */}
          <div className="absolute inset-0 overflow-hidden">
            <div className="absolute inset-0 bg-[radial-gradient(ellipse_80%_50%_at_50%_-20%,rgba(149,110,80,0.15),transparent)]" />
            <div className="absolute top-1/4 left-1/4 w-64 h-64 bg-parchment-900/20 rounded-full blur-3xl" />
            <div className="absolute bottom-1/3 right-1/4 w-96 h-96 bg-ink-900/30 rounded-full blur-3xl" />
            {/* Grain overlay */}
            <div className="absolute inset-0 opacity-[0.03] bg-grain" />
          </div>

          <div className="relative z-10 max-w-4xl mx-auto text-center">
            <div className="inline-flex items-center gap-2 bg-parchment-500/10 border border-parchment-600/30 rounded-full px-4 py-1.5 mb-8 animate-fade-in">
              <Sparkles size={13} className="text-parchment-400" />
              <span className="text-parchment-300 text-xs font-medium tracking-wide">Stories. Shorts. Serialized Fiction.</span>
            </div>

            <h1 className="font-display text-5xl sm:text-6xl md:text-8xl font-bold leading-[0.95] mb-6 animate-fade-up">
              <span className="text-cream">Stories</span>
              <br />
              <span className="gradient-text">that move</span>
              <br />
              <span className="text-cream">you.</span>
            </h1>

            <p className="text-cream/50 text-lg md:text-xl max-w-2xl mx-auto mb-10 leading-relaxed animate-fade-up" style={{ animationDelay: '0.1s' }}>
              Watch vertical shorts. Lose yourself in serialized novels. Romance, thriller, fantasy —
              your next obsession is one scroll away.
            </p>

            <div className="flex flex-col sm:flex-row items-center justify-center gap-4 animate-fade-up" style={{ animationDelay: '0.2s' }}>
              <Link href="/shorts" className="btn-primary flex items-center gap-2 text-base px-8 py-4">
                <Play size={18} fill="currentColor" /> Watch Shorts
              </Link>
              <Link href="/novels" className="btn-ghost flex items-center gap-2 text-base px-8 py-4">
                <BookOpen size={18} /> Browse Novels
              </Link>
            </div>

            {/* Social proof */}
            <div className="mt-14 flex items-center justify-center gap-6 text-cream/30 text-sm animate-fade-up" style={{ animationDelay: '0.3s' }}>
              <span>50K+ readers</span>
              <span className="w-1 h-1 rounded-full bg-cream/20" />
              <span>10K+ chapters</span>
              <span className="w-1 h-1 rounded-full bg-cream/20" />
              <span>500+ creators</span>
            </div>
          </div>
        </section>

        {/* ── FEATURED NOVELS ── */}
        {featuredNovels && featuredNovels.length > 0 && (
          <section className="py-20 px-4">
            <div className="max-w-7xl mx-auto">
              <div className="flex items-end justify-between mb-8">
                <div>
                  <p className="text-parchment-500 text-xs font-mono tracking-widest uppercase mb-2">Serialized Fiction</p>
                  <h2 className="font-display text-3xl md:text-4xl font-bold text-cream">Top Novels</h2>
                </div>
                <Link href="/novels" className="flex items-center gap-1.5 text-parchment-400 hover:text-parchment-300 text-sm transition-colors">
                  View all <ArrowRight size={14} />
                </Link>
              </div>

              <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-3 md:gap-4">
                {featuredNovels.map((novel, i) => (
                  <Link
                    key={novel.id}
                    href={`/novels/${novel.slug}`}
                    className="group"
                    style={{ animationDelay: `${i * 0.05}s` }}
                  >
                    <div className="card-novel">
                      <div className="relative aspect-[2/3] bg-ink-900">
                        {novel.cover_url ? (
                          <Image src={novel.cover_url} alt={novel.title} fill className="object-cover" />
                        ) : (
                          <div className="w-full h-full bg-gradient-to-br from-parchment-900 to-ink-900 flex items-center justify-center">
                            <BookOpen size={24} className="text-parchment-700" />
                          </div>
                        )}
                      </div>
                      <div className="p-2.5">
                        <h3 className="text-cream text-xs font-semibold line-clamp-2 mb-1 group-hover:text-parchment-300 transition-colors">
                          {novel.title}
                        </h3>
                        <div className="flex items-center gap-1">
                          <Star size={9} className="text-parchment-400 fill-parchment-400" />
                          <span className="text-cream/40 text-xs">{novel.rating?.toFixed(1) || '—'}</span>
                        </div>
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            </div>
          </section>
        )}

        {/* ── FEATURED SHORTS ── */}
        {featuredShorts && featuredShorts.length > 0 && (
          <section className="py-20 px-4 bg-ink-950/40">
            <div className="max-w-7xl mx-auto">
              <div className="flex items-end justify-between mb-8">
                <div>
                  <p className="text-parchment-500 text-xs font-mono tracking-widest uppercase mb-2">Short Videos</p>
                  <h2 className="font-display text-3xl md:text-4xl font-bold text-cream">Trending Shorts</h2>
                </div>
                <Link href="/shorts" className="flex items-center gap-1.5 text-parchment-400 hover:text-parchment-300 text-sm transition-colors">
                  View all <ArrowRight size={14} />
                </Link>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {featuredShorts.map((short) => (
                  <Link key={short.id} href="/shorts" className="group relative aspect-[9/16] rounded-2xl overflow-hidden bg-ink-900">
                    {short.thumbnail_url ? (
                      <Image src={short.thumbnail_url} alt={short.title} fill className="object-cover group-hover:scale-105 transition-transform duration-500" />
                    ) : (
                      <div className="w-full h-full bg-gradient-to-br from-ink-800 to-ink-950" />
                    )}
                    <div className="absolute inset-0 bg-gradient-to-t from-obsidian/90 via-transparent to-transparent" />
                    <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                      <div className="w-14 h-14 bg-parchment-500/90 rounded-full flex items-center justify-center">
                        <Play size={24} fill="currentColor" className="text-obsidian ml-1" />
                      </div>
                    </div>
                    <div className="absolute bottom-0 left-0 right-0 p-3">
                      <p className="text-cream text-xs font-semibold line-clamp-2">{short.title}</p>
                      {short.genre && (
                        <span className="text-parchment-400 text-xs">#{short.genre}</span>
                      )}
                    </div>
                  </Link>
                ))}
              </div>
            </div>
          </section>
        )}

        {/* ── CTA ── */}
        <section className="py-24 px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="font-display text-4xl md:text-5xl font-bold text-cream mb-4">
              Ready to get lost<br />
              <span className="gradient-text">in a story?</span>
            </h2>
            <p className="text-cream/50 text-lg mb-10">
              Join thousands of readers and creators on StoryLoom.
              Free to start, premium to obsess.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/auth/sign-up" className="btn-primary text-base px-8 py-4">Create free account</Link>
              <Link href="/pricing" className="btn-ghost text-base px-8 py-4 flex items-center gap-2">
                <Sparkles size={16} /> See Premium plans
              </Link>
            </div>
          </div>
        </section>

        {/* Footer */}
        <footer className="border-t border-ink-800/40 py-10 px-4">
          <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
            <span className="font-display text-xl font-bold gradient-text">StoryLoom</span>
            <div className="flex gap-6 text-cream/40 text-sm">
              <Link href="/novels" className="hover:text-cream/70 transition-colors">Novels</Link>
              <Link href="/shorts" className="hover:text-cream/70 transition-colors">Shorts</Link>
              <Link href="/pricing" className="hover:text-cream/70 transition-colors">Premium</Link>
              <Link href="/auth/sign-up" className="hover:text-cream/70 transition-colors">Sign up</Link>
            </div>
            <p className="text-cream/20 text-xs">© {new Date().getFullYear()} StoryLoom. All rights reserved.</p>
          </div>
        </footer>
      </main>
    </>
  )
}
