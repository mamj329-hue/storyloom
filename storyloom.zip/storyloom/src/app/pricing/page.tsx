// src/app/pricing/page.tsx
import type { Metadata } from 'next'
import { currentUser } from '@clerk/nextjs/server'
import { createAdminClient } from '@/lib/supabase/server'
import { PRICING_PLANS } from '@/types'
import PricingCards from '@/components/shared/PricingCards'
import { CheckCircle } from 'lucide-react'

export const metadata: Metadata = {
  title: 'Premium Plans',
  description: 'Unlock unlimited access to premium stories and shorts.',
}

export default async function PricingPage() {
  const clerkUser = await currentUser()
  let currentPlan = 'free'

  if (clerkUser) {
    const supabase = createAdminClient()
    const { data } = await supabase
      .from('users')
      .select('subscription_status')
      .eq('clerk_id', clerkUser.id)
      .single()
    currentPlan = data?.subscription_status || 'free'
  }

  return (
    <main className="min-h-screen pt-24 pb-20">
      <div className="max-w-5xl mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-14">
          <span className="text-parchment-500 text-sm font-mono tracking-widest uppercase mb-4 block">
            StoryLoom Premium
          </span>
          <h1 className="font-display text-4xl md:text-6xl font-bold text-cream mb-4 leading-tight">
            Stories without<br />
            <span className="gradient-text">limits</span>
          </h1>
          <p className="text-cream/50 text-lg max-w-xl mx-auto">
            Unlock the full library — every chapter, every short, every genre.
            Cancel anytime.
          </p>
        </div>

        {/* Pricing cards */}
        <PricingCards plans={PRICING_PLANS} currentPlan={currentPlan} userEmail={clerkUser?.emailAddresses[0]?.emailAddress} />

        {/* Trust signals */}
        <div className="mt-16 grid grid-cols-1 sm:grid-cols-3 gap-6 text-center">
          {[
            { label: 'Cancel anytime', sub: 'No contracts or commitment' },
            { label: 'Secure payments', sub: 'Powered by Paystack' },
            { label: '10,000+ chapters', sub: 'New content added weekly' },
          ].map(({ label, sub }) => (
            <div key={label} className="flex flex-col items-center gap-1">
              <CheckCircle size={20} className="text-parchment-500 mb-1" />
              <p className="text-cream font-semibold text-sm">{label}</p>
              <p className="text-cream/40 text-xs">{sub}</p>
            </div>
          ))}
        </div>
      </div>
    </main>
  )
}
