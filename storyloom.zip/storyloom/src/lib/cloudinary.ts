// src/lib/cloudinary.ts
import { v2 as cloudinary } from 'cloudinary'

cloudinary.config({
  cloud_name: process.env.NEXT_PUBLIC_CLOUDINARY_CLOUD_NAME,
  api_key: process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET,
})

export async function uploadVideo(file: string, folder = 'storyloom/shorts') {
  return cloudinary.uploader.upload(file, {
    resource_type: 'video',
    folder,
    eager: [{ width: 720, height: 1280, crop: 'fill', format: 'mp4' }],
    eager_async: true,
  })
}

export async function uploadImage(file: string, folder = 'storyloom/covers') {
  return cloudinary.uploader.upload(file, {
    resource_type: 'image',
    folder,
    transformation: [{ width: 800, height: 1200, crop: 'fill', quality: 'auto' }],
  })
}

export async function deleteAsset(publicId: string, resourceType: 'image' | 'video' = 'image') {
  return cloudinary.uploader.destroy(publicId, { resource_type: resourceType })
}

export function getVideoThumbnail(publicId: string) {
  return cloudinary.url(publicId, {
    resource_type: 'video',
    format: 'jpg',
    transformation: [{ width: 400, height: 711, crop: 'fill' }],
  })
}

export default cloudinary
