// src/lib/paystack.ts
import axios from 'axios'

const PAYSTACK_BASE = 'https://api.paystack.co'

const paystackApi = axios.create({
  baseURL: PAYSTACK_BASE,
  headers: {
    Authorization: `Bearer ${process.env.PAYSTACK_SECRET_KEY}`,
    'Content-Type': 'application/json',
  },
})

export interface InitializeTransactionParams {
  email: string
  amount: number // in kobo (NGN × 100)
  reference?: string
  plan?: string
  callback_url?: string
  metadata?: Record<string, unknown>
}

export async function initializeTransaction(params: InitializeTransactionParams) {
  const { data } = await paystackApi.post('/transaction/initialize', {
    ...params,
    amount: params.amount, // already in kobo
    callback_url: params.callback_url || `${process.env.NEXT_PUBLIC_APP_URL}/api/subscriptions/verify`,
  })
  return data.data as { authorization_url: string; access_code: string; reference: string }
}

export async function verifyTransaction(reference: string) {
  const { data } = await paystackApi.get(`/transaction/verify/${reference}`)
  return data.data
}

export async function createCustomer(email: string, firstName: string, lastName: string) {
  const { data } = await paystackApi.post('/customer', {
    email,
    first_name: firstName,
    last_name: lastName,
  })
  return data.data
}

export async function createSubscription(params: {
  customer: string
  plan: string
  authorization?: string
}) {
  const { data } = await paystackApi.post('/subscription', params)
  return data.data
}

export async function cancelSubscription(code: string, token: string) {
  const { data } = await paystackApi.post('/subscription/disable', {
    code,
    token,
  })
  return data
}

export async function fetchSubscription(code: string) {
  const { data } = await paystackApi.get(`/subscription/${code}`)
  return data.data
}

export function generateReference(prefix = 'SL') {
  return `${prefix}_${Date.now()}_${Math.random().toString(36).slice(2, 8).toUpperCase()}`
}

export function verifyWebhookSignature(body: string, signature: string): boolean {
  const crypto = require('crypto')
  const hash = crypto
    .createHmac('sha512', process.env.PAYSTACK_WEBHOOK_SECRET!)
    .update(body)
    .digest('hex')
  return hash === signature
}

export const PAYSTACK_PLANS = {
  basic: {
    name: 'Reader Plan',
    amount: 150000, // ₦1,500 in kobo
    interval: 'monthly',
  },
  premium: {
    name: 'Unlimited Plan',
    amount: 350000, // ₦3,500 in kobo
    interval: 'monthly',
  },
}
