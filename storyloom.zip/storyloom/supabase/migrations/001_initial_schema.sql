-- ============================================
-- STORYLOOM Database Schema
-- Run in Supabase SQL Editor
-- ============================================

-- Enable extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pg_trgm";

-- ============================================
-- USERS (synced from Clerk via webhook)
-- ============================================
CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  clerk_id TEXT UNIQUE NOT NULL,
  email TEXT UNIQUE NOT NULL,
  username TEXT UNIQUE,
  display_name TEXT,
  avatar_url TEXT,
  bio TEXT,
  is_creator BOOLEAN DEFAULT FALSE,
  is_admin BOOLEAN DEFAULT FALSE,
  subscription_status TEXT DEFAULT 'free' CHECK (subscription_status IN ('free', 'basic', 'premium')),
  subscription_expires_at TIMESTAMPTZ,
  paystack_customer_code TEXT,
  total_earnings DECIMAL(12,2) DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================
-- SHORTS (TikTok-style vertical videos)
-- ============================================
CREATE TABLE shorts (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  creator_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  description TEXT,
  video_url TEXT NOT NULL,
  thumbnail_url TEXT,
  cloudinary_public_id TEXT,
  duration_seconds INTEGER,
  is_premium BOOLEAN DEFAULT FALSE,
  is_published BOOLEAN DEFAULT FALSE,
  view_count INTEGER DEFAULT 0,
  like_count INTEGER DEFAULT 0,
  comment_count INTEGER DEFAULT 0,
  tags TEXT[] DEFAULT '{}',
  genre TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================
-- NOVELS
-- ============================================
CREATE TABLE novels (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  creator_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  slug TEXT UNIQUE NOT NULL,
  synopsis TEXT,
  cover_url TEXT,
  cloudinary_public_id TEXT,
  genre TEXT NOT NULL,
  tags TEXT[] DEFAULT '{}',
  status TEXT DEFAULT 'ongoing' CHECK (status IN ('ongoing', 'completed', 'hiatus')),
  is_published BOOLEAN DEFAULT FALSE,
  is_premium BOOLEAN DEFAULT FALSE,
  total_chapters INTEGER DEFAULT 0,
  view_count INTEGER DEFAULT 0,
  like_count INTEGER DEFAULT 0,
  rating DECIMAL(3,2) DEFAULT 0,
  rating_count INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================
-- CHAPTERS
-- ============================================
CREATE TABLE chapters (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  novel_id UUID NOT NULL REFERENCES novels(id) ON DELETE CASCADE,
  chapter_number INTEGER NOT NULL,
  title TEXT NOT NULL,
  content TEXT NOT NULL,
  word_count INTEGER DEFAULT 0,
  is_premium BOOLEAN DEFAULT FALSE,
  is_published BOOLEAN DEFAULT FALSE,
  view_count INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(novel_id, chapter_number)
);

-- ============================================
-- SUBSCRIPTIONS
-- ============================================
CREATE TABLE subscriptions (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  plan TEXT NOT NULL CHECK (plan IN ('basic', 'premium')),
  status TEXT NOT NULL CHECK (status IN ('active', 'cancelled', 'expired', 'pending')),
  paystack_subscription_code TEXT UNIQUE,
  paystack_plan_code TEXT,
  amount DECIMAL(10,2) NOT NULL,
  currency TEXT DEFAULT 'NGN',
  current_period_start TIMESTAMPTZ,
  current_period_end TIMESTAMPTZ,
  cancelled_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================
-- PAYMENTS
-- ============================================
CREATE TABLE payments (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  subscription_id UUID REFERENCES subscriptions(id),
  paystack_reference TEXT UNIQUE NOT NULL,
  paystack_transaction_id TEXT,
  amount DECIMAL(10,2) NOT NULL,
  currency TEXT DEFAULT 'NGN',
  status TEXT NOT NULL CHECK (status IN ('pending', 'success', 'failed', 'refunded')),
  metadata JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================
-- LIKES
-- ============================================
CREATE TABLE likes (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  content_type TEXT NOT NULL CHECK (content_type IN ('short', 'novel', 'chapter')),
  content_id UUID NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id, content_type, content_id)
);

-- ============================================
-- COMMENTS
-- ============================================
CREATE TABLE comments (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  content_type TEXT NOT NULL CHECK (content_type IN ('short', 'novel', 'chapter')),
  content_id UUID NOT NULL,
  parent_id UUID REFERENCES comments(id) ON DELETE CASCADE,
  body TEXT NOT NULL,
  like_count INTEGER DEFAULT 0,
  is_pinned BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================
-- READING PROGRESS
-- ============================================
CREATE TABLE reading_progress (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  novel_id UUID NOT NULL REFERENCES novels(id) ON DELETE CASCADE,
  last_chapter_id UUID REFERENCES chapters(id),
  last_chapter_number INTEGER DEFAULT 0,
  completed BOOLEAN DEFAULT FALSE,
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id, novel_id)
);

-- ============================================
-- BOOKMARKS
-- ============================================
CREATE TABLE bookmarks (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  content_type TEXT NOT NULL CHECK (content_type IN ('short', 'novel')),
  content_id UUID NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id, content_type, content_id)
);

-- ============================================
-- FOLLOWS
-- ============================================
CREATE TABLE follows (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  follower_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  following_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(follower_id, following_id)
);

-- ============================================
-- CREATOR EARNINGS
-- ============================================
CREATE TABLE creator_earnings (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  creator_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  source_type TEXT NOT NULL CHECK (source_type IN ('subscription_share', 'tip', 'bonus')),
  amount DECIMAL(10,2) NOT NULL,
  currency TEXT DEFAULT 'NGN',
  description TEXT,
  payment_id UUID REFERENCES payments(id),
  paid_out BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================
-- INDEXES
-- ============================================
CREATE INDEX idx_shorts_creator ON shorts(creator_id);
CREATE INDEX idx_shorts_published ON shorts(is_published, created_at DESC);
CREATE INDEX idx_shorts_tags ON shorts USING GIN(tags);
CREATE INDEX idx_novels_creator ON novels(creator_id);
CREATE INDEX idx_novels_slug ON novels(slug);
CREATE INDEX idx_novels_published ON novels(is_published, created_at DESC);
CREATE INDEX idx_chapters_novel ON chapters(novel_id, chapter_number);
CREATE INDEX idx_comments_content ON comments(content_type, content_id, created_at DESC);
CREATE INDEX idx_likes_user ON likes(user_id);
CREATE INDEX idx_subscriptions_user ON subscriptions(user_id, status);
CREATE INDEX idx_reading_progress_user ON reading_progress(user_id);

-- ============================================
-- ROW LEVEL SECURITY
-- ============================================
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE shorts ENABLE ROW LEVEL SECURITY;
ALTER TABLE novels ENABLE ROW LEVEL SECURITY;
ALTER TABLE chapters ENABLE ROW LEVEL SECURITY;
ALTER TABLE subscriptions ENABLE ROW LEVEL SECURITY;
ALTER TABLE likes ENABLE ROW LEVEL SECURITY;
ALTER TABLE comments ENABLE ROW LEVEL SECURITY;
ALTER TABLE reading_progress ENABLE ROW LEVEL SECURITY;
ALTER TABLE bookmarks ENABLE ROW LEVEL SECURITY;
ALTER TABLE follows ENABLE ROW LEVEL SECURITY;

-- Users: public read, own write
CREATE POLICY "Users are publicly readable" ON users FOR SELECT USING (TRUE);
CREATE POLICY "Users can update own profile" ON users FOR UPDATE USING (clerk_id = current_setting('app.clerk_id', TRUE));

-- Shorts: published are public, own are full access
CREATE POLICY "Published shorts are public" ON shorts FOR SELECT USING (is_published = TRUE OR creator_id = (SELECT id FROM users WHERE clerk_id = current_setting('app.clerk_id', TRUE)));
CREATE POLICY "Creators manage own shorts" ON shorts FOR ALL USING (creator_id = (SELECT id FROM users WHERE clerk_id = current_setting('app.clerk_id', TRUE)));

-- Novels: published are public
CREATE POLICY "Published novels are public" ON novels FOR SELECT USING (is_published = TRUE OR creator_id = (SELECT id FROM users WHERE clerk_id = current_setting('app.clerk_id', TRUE)));
CREATE POLICY "Creators manage own novels" ON novels FOR ALL USING (creator_id = (SELECT id FROM users WHERE clerk_id = current_setting('app.clerk_id', TRUE)));

-- Chapters: non-premium public, premium requires subscription
CREATE POLICY "Free chapters are public" ON chapters FOR SELECT USING (
  is_published = TRUE AND (
    is_premium = FALSE OR
    EXISTS (
      SELECT 1 FROM subscriptions s
      JOIN users u ON u.id = s.user_id
      WHERE u.clerk_id = current_setting('app.clerk_id', TRUE)
      AND s.status = 'active'
    )
  )
);

-- Likes, comments, bookmarks, follows
CREATE POLICY "Likes are public" ON likes FOR SELECT USING (TRUE);
CREATE POLICY "Authenticated users can like" ON likes FOR INSERT WITH CHECK (user_id = (SELECT id FROM users WHERE clerk_id = current_setting('app.clerk_id', TRUE)));
CREATE POLICY "Users can unlike" ON likes FOR DELETE USING (user_id = (SELECT id FROM users WHERE clerk_id = current_setting('app.clerk_id', TRUE)));

CREATE POLICY "Comments are public" ON comments FOR SELECT USING (TRUE);
CREATE POLICY "Authenticated users can comment" ON comments FOR INSERT WITH CHECK (user_id = (SELECT id FROM users WHERE clerk_id = current_setting('app.clerk_id', TRUE)));
CREATE POLICY "Users manage own comments" ON comments FOR UPDATE USING (user_id = (SELECT id FROM users WHERE clerk_id = current_setting('app.clerk_id', TRUE)));

CREATE POLICY "Own subscriptions" ON subscriptions FOR SELECT USING (user_id = (SELECT id FROM users WHERE clerk_id = current_setting('app.clerk_id', TRUE)));
CREATE POLICY "Own bookmarks" ON bookmarks FOR ALL USING (user_id = (SELECT id FROM users WHERE clerk_id = current_setting('app.clerk_id', TRUE)));
CREATE POLICY "Follows are public" ON follows FOR SELECT USING (TRUE);
CREATE POLICY "Own follows" ON follows FOR ALL USING (follower_id = (SELECT id FROM users WHERE clerk_id = current_setting('app.clerk_id', TRUE)));
CREATE POLICY "Own progress" ON reading_progress FOR ALL USING (user_id = (SELECT id FROM users WHERE clerk_id = current_setting('app.clerk_id', TRUE)));

-- ============================================
-- FUNCTIONS & TRIGGERS
-- ============================================

-- Auto-update updated_at
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN NEW.updated_at = NOW(); RETURN NEW; END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_users_updated_at BEFORE UPDATE ON users FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER trg_shorts_updated_at BEFORE UPDATE ON shorts FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER trg_novels_updated_at BEFORE UPDATE ON novels FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER trg_chapters_updated_at BEFORE UPDATE ON chapters FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- Auto word count on chapter insert/update
CREATE OR REPLACE FUNCTION calculate_word_count()
RETURNS TRIGGER AS $$
BEGIN
  NEW.word_count = array_length(string_to_array(trim(NEW.content), ' '), 1);
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_chapter_word_count BEFORE INSERT OR UPDATE ON chapters FOR EACH ROW EXECUTE FUNCTION calculate_word_count();

-- Update novel chapter count
CREATE OR REPLACE FUNCTION update_novel_chapter_count()
RETURNS TRIGGER AS $$
BEGIN
  UPDATE novels SET total_chapters = (
    SELECT COUNT(*) FROM chapters WHERE novel_id = COALESCE(NEW.novel_id, OLD.novel_id) AND is_published = TRUE
  ) WHERE id = COALESCE(NEW.novel_id, OLD.novel_id);
  RETURN COALESCE(NEW, OLD);
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_chapter_count AFTER INSERT OR UPDATE OR DELETE ON chapters FOR EACH ROW EXECUTE FUNCTION update_novel_chapter_count();
