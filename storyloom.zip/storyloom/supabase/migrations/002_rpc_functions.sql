-- ============================================
-- STORYLOOM Migration 002
-- Additional RPC functions & helpers
-- Run in Supabase SQL Editor after 001
-- ============================================

-- Increment comment count on shorts
CREATE OR REPLACE FUNCTION increment_comment_count(short_id UUID)
RETURNS void AS $$
BEGIN
  UPDATE shorts SET comment_count = comment_count + 1 WHERE id = short_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Increment like count (used by API route)
CREATE OR REPLACE FUNCTION increment_like_count(row_id UUID, table_name TEXT)
RETURNS void AS $$
BEGIN
  IF table_name = 'shorts' THEN
    UPDATE shorts SET like_count = like_count + 1 WHERE id = row_id;
  ELSIF table_name = 'novels' THEN
    UPDATE novels SET like_count = like_count + 1 WHERE id = row_id;
  END IF;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Decrement like count
CREATE OR REPLACE FUNCTION decrement_like_count(row_id UUID, table_name TEXT)
RETURNS void AS $$
BEGIN
  IF table_name = 'shorts' THEN
    UPDATE shorts SET like_count = GREATEST(like_count - 1, 0) WHERE id = row_id;
  ELSIF table_name = 'novels' THEN
    UPDATE novels SET like_count = GREATEST(like_count - 1, 0) WHERE id = row_id;
  END IF;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Increment view count on shorts
CREATE OR REPLACE FUNCTION increment_short_views(short_id UUID)
RETURNS void AS $$
BEGIN
  UPDATE shorts SET view_count = view_count + 1 WHERE id = short_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Increment view count on novels
CREATE OR REPLACE FUNCTION increment_novel_views(novel_id UUID)
RETURNS void AS $$
BEGIN
  UPDATE novels SET view_count = view_count + 1 WHERE id = novel_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Get creator stats summary
CREATE OR REPLACE FUNCTION get_creator_stats(creator_uuid UUID)
RETURNS TABLE (
  total_shorts BIGINT,
  total_novels BIGINT,
  total_views BIGINT,
  total_likes BIGINT,
  total_comments BIGINT
) AS $$
BEGIN
  RETURN QUERY
  SELECT
    (SELECT COUNT(*) FROM shorts WHERE creator_id = creator_uuid)::BIGINT AS total_shorts,
    (SELECT COUNT(*) FROM novels WHERE creator_id = creator_uuid)::BIGINT AS total_novels,
    (
      COALESCE((SELECT SUM(view_count) FROM shorts WHERE creator_id = creator_uuid), 0) +
      COALESCE((SELECT SUM(view_count) FROM novels WHERE creator_id = creator_uuid), 0)
    )::BIGINT AS total_views,
    (
      COALESCE((SELECT SUM(like_count) FROM shorts WHERE creator_id = creator_uuid), 0) +
      COALESCE((SELECT SUM(like_count) FROM novels WHERE creator_id = creator_uuid), 0)
    )::BIGINT AS total_likes,
    COALESCE((SELECT SUM(comment_count) FROM shorts WHERE creator_id = creator_uuid), 0)::BIGINT AS total_comments;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Admin: platform-wide stats
CREATE OR REPLACE FUNCTION get_platform_stats()
RETURNS TABLE (
  total_users BIGINT,
  total_creators BIGINT,
  active_subscribers BIGINT,
  total_novels BIGINT,
  total_shorts BIGINT,
  total_chapters BIGINT
) AS $$
BEGIN
  RETURN QUERY
  SELECT
    (SELECT COUNT(*) FROM users)::BIGINT,
    (SELECT COUNT(*) FROM users WHERE is_creator = TRUE)::BIGINT,
    (SELECT COUNT(*) FROM subscriptions WHERE status = 'active')::BIGINT,
    (SELECT COUNT(*) FROM novels WHERE is_published = TRUE)::BIGINT,
    (SELECT COUNT(*) FROM shorts WHERE is_published = TRUE)::BIGINT,
    (SELECT COUNT(*) FROM chapters WHERE is_published = TRUE)::BIGINT;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Search novels full-text
CREATE INDEX IF NOT EXISTS idx_novels_fts ON novels
  USING GIN(to_tsvector('english', title || ' ' || COALESCE(synopsis, '')));

CREATE OR REPLACE FUNCTION search_novels(query TEXT, lim INT DEFAULT 20, off INT DEFAULT 0)
RETURNS SETOF novels AS $$
BEGIN
  RETURN QUERY
  SELECT * FROM novels
  WHERE is_published = TRUE
    AND to_tsvector('english', title || ' ' || COALESCE(synopsis, '')) @@ plainto_tsquery('english', query)
  ORDER BY ts_rank(
    to_tsvector('english', title || ' ' || COALESCE(synopsis, '')),
    plainto_tsquery('english', query)
  ) DESC
  LIMIT lim OFFSET off;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
