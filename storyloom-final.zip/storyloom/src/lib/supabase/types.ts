// Auto-generated Supabase type helpers
// Run: npx supabase gen types typescript --project-id YOUR_PROJECT_ID > src/lib/supabase/types.ts

export type Json = string | number | boolean | null | { [key: string]: Json | undefined } | Json[]

export interface Database {
  public: {
    Tables: {
      users: {
        Row: {
          id: string
          clerk_id: string
          email: string
          username: string | null
          display_name: string | null
          avatar_url: string | null
          bio: string | null
          is_creator: boolean
          is_admin: boolean
          subscription_status: string
          subscription_expires_at: string | null
          paystack_customer_code: string | null
          total_earnings: number
          created_at: string
          updated_at: string
        }
        Insert: Omit<Database['public']['Tables']['users']['Row'], 'id' | 'created_at' | 'updated_at'>
        Update: Partial<Database['public']['Tables']['users']['Insert']>
      }
      shorts: {
        Row: {
          id: string
          creator_id: string
          title: string
          description: string | null
          video_url: string
          thumbnail_url: string | null
          cloudinary_public_id: string | null
          duration_seconds: number | null
          is_premium: boolean
          is_published: boolean
          view_count: number
          like_count: number
          comment_count: number
          tags: string[]
          genre: string | null
          created_at: string
          updated_at: string
        }
        Insert: Omit<Database['public']['Tables']['shorts']['Row'], 'id' | 'created_at' | 'updated_at' | 'view_count' | 'like_count' | 'comment_count'>
        Update: Partial<Database['public']['Tables']['shorts']['Insert']>
      }
      novels: {
        Row: {
          id: string
          creator_id: string
          title: string
          slug: string
          synopsis: string | null
          cover_url: string | null
          cloudinary_public_id: string | null
          genre: string
          tags: string[]
          status: string
          is_published: boolean
          is_premium: boolean
          total_chapters: number
          view_count: number
          like_count: number
          rating: number
          rating_count: number
          created_at: string
          updated_at: string
        }
        Insert: Omit<Database['public']['Tables']['novels']['Row'], 'id' | 'created_at' | 'updated_at' | 'total_chapters' | 'view_count' | 'like_count' | 'rating' | 'rating_count'>
        Update: Partial<Database['public']['Tables']['novels']['Insert']>
      }
      chapters: {
        Row: {
          id: string
          novel_id: string
          chapter_number: number
          title: string
          content: string
          word_count: number
          is_premium: boolean
          is_published: boolean
          view_count: number
          created_at: string
          updated_at: string
        }
        Insert: Omit<Database['public']['Tables']['chapters']['Row'], 'id' | 'created_at' | 'updated_at' | 'word_count' | 'view_count'>
        Update: Partial<Database['public']['Tables']['chapters']['Insert']>
      }
    }
    Functions: {
      increment_like_count: { Args: { row_id: string; table_name: string }; Returns: void }
      decrement_like_count: { Args: { row_id: string; table_name: string }; Returns: void }
      increment_short_views: { Args: { short_id: string }; Returns: void }
      increment_novel_views: { Args: { novel_id: string }; Returns: void }
      increment_comment_count: { Args: { short_id: string }; Returns: void }
      get_creator_stats: { Args: { creator_uuid: string }; Returns: { total_shorts: number; total_novels: number; total_views: number; total_likes: number; total_comments: number }[] }
    }
  }
}
