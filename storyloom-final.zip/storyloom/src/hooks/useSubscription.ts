'use client'
import { useEffect, useState } from 'react'
import { useUser } from '@clerk/nextjs'
import { createClient } from '@/lib/supabase/client'

export function useSubscription() {
  const { user, isLoaded } = useUser()
  const [status, setStatus] = useState<'free' | 'basic' | 'premium'>('free')
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (!isLoaded) return
    if (!user) { setStatus('free'); setLoading(false); return }

    const supabase = createClient()
    supabase
      .from('users')
      .select('subscription_status, subscription_expires_at')
      .eq('clerk_id', user.id)
      .single()
      .then(({ data }) => {
        if (data) {
          const expired =
            data.subscription_expires_at &&
            new Date(data.subscription_expires_at) < new Date()
          setStatus(expired ? 'free' : (data.subscription_status as any) || 'free')
        }
        setLoading(false)
      })
  }, [user, isLoaded])

  return { status, loading, isPremium: status === 'premium', isBasic: status === 'basic' || status === 'premium' }
}
