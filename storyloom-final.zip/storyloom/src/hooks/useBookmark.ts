'use client'
import { useState } from 'react'
import { useUser } from '@clerk/nextjs'
import toast from 'react-hot-toast'

export function useBookmark(contentType: 'short' | 'novel', contentId: string, initial = false) {
  const { isSignedIn } = useUser()
  const [bookmarked, setBookmarked] = useState(initial)
  const [loading, setLoading] = useState(false)

  const toggle = async () => {
    if (!isSignedIn) { toast.error('Sign in to bookmark'); return }
    setLoading(true)
    const next = !bookmarked
    setBookmarked(next)
    try {
      await fetch('/api/bookmarks', {
        method: next ? 'POST' : 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ content_type: contentType, content_id: contentId }),
      })
    } catch {
      setBookmarked(!next)
      toast.error('Failed to update bookmark')
    } finally {
      setLoading(false)
    }
  }

  return { bookmarked, toggle, loading }
}
