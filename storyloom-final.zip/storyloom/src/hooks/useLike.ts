'use client'
import { useState } from 'react'
import { useUser } from '@clerk/nextjs'
import toast from 'react-hot-toast'

export function useLike(
  contentType: 'short' | 'novel' | 'chapter',
  contentId: string,
  initialLiked = false,
  initialCount = 0
) {
  const { isSignedIn } = useUser()
  const [liked, setLiked] = useState(initialLiked)
  const [count, setCount] = useState(initialCount)
  const [loading, setLoading] = useState(false)

  const toggle = async () => {
    if (!isSignedIn) { toast.error('Sign in to like'); return }
    setLoading(true)
    const next = !liked
    setLiked(next)
    setCount(c => next ? c + 1 : Math.max(c - 1, 0))
    try {
      await fetch('/api/likes', {
        method: next ? 'POST' : 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ content_type: contentType, content_id: contentId }),
      })
    } catch {
      setLiked(!next)
      setCount(c => next ? Math.max(c - 1, 0) : c + 1)
      toast.error('Failed to update like')
    } finally {
      setLoading(false)
    }
  }

  return { liked, count, toggle, loading }
}
